# DAVID — Frontend Specialist Reference (Router)

Scanners F, G, T, U master index. 4 files covering accessibility (WCAG 2.2), internationalization, SEO, and observability/logging.

## Which file to load?

| When auditing... | Load |
|------------------|------|
| WCAG 2.2 Level A + AA, ARIA, keyboard navigation, color contrast | `references/frontend/accessibility.md` |
| Hardcoded strings, string concat, locale ops, RTL layout, fixed containers | `references/frontend/i18n.md` |
| Meta tags, OG/Twitter cards, structured data, noindex bugs, canonical errors | `references/frontend/seo.md` |
| Structured logging, log levels, PII in logs, missing tracing, health check endpoint | `references/frontend/observability.md` |
| **Full frontend specialist audit** | **All 4 files** |

## Sub-file Summary

| File | Scanner | Lines | Use Case |
|------|---------|-------|----------|
| `frontend/accessibility.md` | F — A11Y | ~348 | HTML / JSX / Vue / Svelte files |
| `frontend/i18n.md` | G — I18N | ~271 | "localize" / multi-region / hardcoded text |
| `frontend/seo.md` | T — SEO | ~295 | Next.js / Nuxt / SSR / SSG pages |
| `frontend/observability.md` | U — OBSERV | ~270 | Production backend / API routes |

## Loading Rules

```
HTML / JSX / Vue / Svelte    → frontend/accessibility.md
"localize" / multi-region    → frontend/i18n.md
Next.js / Nuxt / SSR pages   → frontend/seo.md
production backend / APIs    → frontend/observability.md
```

> Note: `frontend/observability.md` covers backend logging and tracing. For frontend-specific performance, see `references/code/performance.md`.
