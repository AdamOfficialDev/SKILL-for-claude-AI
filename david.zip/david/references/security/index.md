# DAVID — Security Reference (Router)

Scanner B, AC, and AE master index. 2 files covering security audit (OWASP, secrets, ReDoS) and privacy/GDPR compliance.

## Which file to load?

| When auditing... | Load |
|------------------|------|
| OWASP Top 10, secrets detection, ReDoS, supply chain, path traversal, file upload, input sanitization | `references/security/audit.md` |
| PII flow mapping, GDPR Art.17 erasure, data minimization, consent, retention | `references/security/gdpr.md` |
| **Full security + privacy audit** | **Both files** |

## Sub-file Summary

| File | Scanners | Lines | Use Case |
|------|----------|-------|----------|
| `security/audit.md` | B — SECURITY + AC — INPUTSANIT | ~428 | Always-on security scan; every code interaction |
| `security/gdpr.md` | AE — GDPR | ~324 | User data handling, PII, consent flows |

## Loading Rules

```
Always (Scanner B always on)     → security/audit.md
User data / PII detected         → security/gdpr.md
File uploads / user input        → security/audit.md (AC owns INPUTSANIT card)
"gdpr" / "privacy" mentioned     → security/gdpr.md
```

> ⚠️  Scanner B is **always-on** — `security/audit.md` runs on every code interaction and cannot be suppressed (Law 8).
