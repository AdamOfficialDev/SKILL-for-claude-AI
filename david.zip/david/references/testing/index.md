# DAVID — Testing Reference (Router)

Scanner M, TQ, and pre-delivery testing master index. 3 files covering test generation, test quality auditing, and pre-delivery verification checklists.

## Which file to load?

| When you need... | Load |
|------------------|------|
| Generate regression tests, edge cases, happy path, security/a11y/type/perf tests | `references/testing/generator.md` |
| Audit existing tests for weak assertions, impl-coupling, flaky patterns | `references/testing/quality.md` |
| Pre-delivery 5-tier verification checklist | `references/testing/checklist.md` |
| **Full testing session** | **All 3 files** |

## Sub-file Summary

| File | Scanners | Lines | Use Case |
|------|----------|-------|----------|
| `testing/generator.md` | M — TESTGEN | ~568 | Auto-generate tests post-fix; Tier 3+ only |
| `testing/quality.md` | TQ — TESTQUAL | ~335 | Audit existing *.test.* / *.spec.* files |
| `testing/checklist.md` | Pre-delivery | ~175 | 5-tier verification before any code delivery |

## Loading Rules

```
Post-fix (Tier 3+)         → testing/generator.md
test files submitted       → testing/quality.md
Phase 5 verification       → testing/checklist.md
"generate tests" command   → testing/generator.md
```

> Skip `testing/generator.md` for Tier 1–2 (single question or targeted fix ≤20 lines) — run only on Tier 3+ or explicit user request.
