# DAVID v6.0 — Scanner Map (Index)

Mode triggers, always-on scanners, full scanner table, and deduplication rules.

**This file is always-on** — loaded every session during Phase 1.
**For per-scanner trigger detail, cross-scanner interactions, and tech matrix** → load `references/scanner-map-detail.md` (on-demand, after mode detection).

## Table of Contents

1. [Operating Modes](#1-operating-modes)
2. [Always-On Scanners](#2-always-on-scanners)
3. [Scanner Engine — Full Table](#3-scanner-engine--full-table)
4. [Scanner Deduplication Map](#4-scanner-deduplication-map)

> **Sections 5–7 live in** `references/scanner-map-detail.md`:
> - §5 Scanner Trigger Detail (per-scanner rules, all 40+ scanners)
> - §6 Cross-Scanner Interaction Map
> - §7 Supported Technology Matrix

---

## 1. Operating Modes

DAVID auto-detects which modes to activate. Multiple modes always combine simultaneously.

| Mode | Trigger Keywords / Conditions | Scanner(s) |
|------|-------------------------------|------------|
| DEBUG | error / crash / bug / stack trace / "tidak jalan" | A |
| SECURITY | every code submission (always on) | B |
| PERF | "slow" / "lambat" / "optimize" / N+1 / memory / timeout | C |
| REVIEW | "review" / "PR" / "feedback" / "code quality" | D + E |
| ARCH | "architecture" / "structure" / "SOLID" / multi-file | E |
| UIUX | JSX/TSX/Vue/Svelte/HTML + CSS / "ux" / "form" / "mobile" / "tampilan" | O |
| ENHANCE | "enhance" / "improve" / "polish" / "upgrade" / "tingkatkan" | EN |
| A11Y | HTML / JSX / Vue / Svelte components present | F |
| I18N | "localize" / "locale" / multi-region / hardcoded strings | G |
| DEPS | package.json / requirements.txt / go.mod / Gemfile | H |
| GIT | git diff / "changes since" / "what changed" | I |
| MIGRATE | migration files / DDL / ALTER TABLE | J |
| CICD | Dockerfile / .github/workflows / .gitlab-ci.yml | K |
| EXPLAIN | "explain this" / "walk me through" / first look at new codebase | L |
| TESTGEN | after any fix delivery / "generate tests" / "buat test" | M |
| DOCGEN | after any fix delivery / "generate docs" / "document this" | N |
| TYPES | TypeScript files (.ts / .tsx) / "type error" / "TS error" | P |
| DEADCODE | "cleanup" / "unused" / "remove dead" | Q |
| ERRCOV | "reliability" / async-heavy code / "unhandled" | R |
| COMPLEXITY | any function > 20 lines / "refactor this function" | S |
| SEO | Next.js / Nuxt / Remix / Astro / any SSR app | T |
| OBSERV | "logging" / "monitoring" / "production" / backend code | U |
| BUNDLE | Webpack / Vite / Next.js frontend / "bundle size" | V |
| STATE | Redux / Zustand / Context / Pinia / Jotai present | W |
| PWA | service-worker.js / manifest.json | X |
| ENVCONF | .env / config files / startup entry point | Y |
| FLAGS | feature flags / if (FLAG_X) / isFeatureEnabled() | Z |
| APICONTRACT | API routes / OpenAPI / fetch() / axios calls | AA |
| RATELIMIT | search inputs / form submits / API calls without debounce | AB |
| INPUTSANIT | file uploads / user input handling / FormData | AC |
| TECHDEBT | TODO / FIXME / deprecated / @deprecated / "cleanup" | AD |
| GDPR | user data handling / PII / consent / "privacy" / "GDPR" | AE |
| RESILIENCE | external HTTP calls / DB queries / "timeout" / "circuit breaker" | AF |
| REFACTOR | "refactor" / CC score > 15 / complex restructuring | RF |
| UPGRADE | old patterns / legacy APIs / deprecated usage detected | UA |
| HEALTHSCORE | end of every session (always on) | HS |
| PRDESC | post-fix session with diff / "buatkan PR desc" / "write PR" | AH |
| CHANGELOG | "changelog" / "release notes" / commit list provided | AI |
| CROSSFILE | 2+ files submitted / "check consistency" / multi-file session | AJ |
| VIBECODE | AI-generated code / "vibe coding" / "from Copilot" / high TODO density | AK |
| TESTQUAL | *.test.* / *.spec.* files / "audit tests" / "flaky" | TQ |
| SCHEMA | SQL schema / ORM models (Prisma / SQLAlchemy / TypeORM / Drizzle) | SQ |
| FULL SCAN | code submitted with no specific complaint | ALL |

---

## 2. Always-On Scanners

These scanners / steps activate on **every** code interaction — no trigger required:

| Scanner / Step | When | Cannot be disabled by |
|---------------|------|----------------------|
| **B — SECURITY** | Every code submission | Any user instruction. Always runs. |
| **HS — HEALTHSCORE** | End of every session | Only `david: no health score` command disables it |
| **L — EXPLAIN** (partial) | FULL SCAN with no specific complaint | Auto-includes a codebase orientation step before scanning |
| **Framework Profile** (Phase 1.5) | Every code submission | Auto-detected; falls back to Generic profile if unknown |

> Framework Profile is not a scanner — it is a Phase 1.5 configuration step that adjusts scanner behavior for the detected stack.
> Full profile rules → load on-demand: `references/framework-profiles.md`

> All other scanners are conditional — they activate only when their trigger conditions match.

---

## 3. Scanner Engine — Full Table

All active scanners run simultaneously. Findings are batched by priority (see SKILL.md Phase 2 Fix Priority Order).

| Scanner | Always On | What it does | Load when | Reference |
|---------|:---------:|-------------|-----------|-----------|
| A — BUG | | 5-pass AST-aware: syntax/type → logic → async → resources → integration | any code + error / bug | `references/code/bug-patterns.md` |
| B — SECURITY | ✅ | OWASP Top 10, secrets (15+ families), ReDoS, supply chain | always | `references/security/audit.md` |
| C — PERF | | Big-O, N+1, memory leaks, sync blocking, DB query plan hints | "slow" / DB code / any loop | `references/code/performance.md` |
| D — REVIEW | | Code smells, naming violations, missing error handling, doc gaps | "review" / any code | `references/code/code-review.md` |
| E — ARCH | | SOLID, coupling & cohesion, layer violations, anti-patterns | "architecture" / multi-file | `references/code/architecture.md` |
| F — A11Y | | WCAG 2.2 Level A + AA + new 2.2 criteria | HTML / JSX / Vue / Svelte | `references/frontend/accessibility.md` |
| G — I18N | | Hardcoded strings, string concat, locale ops, RTL, fixed containers | "localize" / multi-region | `references/frontend/i18n.md` |
| H — DEPS | | CVE patterns, license conflicts, abandoned packages, wildcard pins | package.json / requirements | `references/infra/dependencies.md` |
| I — GIT | | Diff parsing, change map, cross-file impact, regression detection | git diff submitted | `references/dx/git-diff.md` |
| J — MIGRATE | | Destructive ops, missing rollback, non-idempotent, table locks | migration / DDL files | `references/infra/cicd.md` |
| K — CICD | | Docker (non-root, caching, secrets), GitHub Actions (SHA pinning, permissions) | Dockerfile / workflow yml | `references/infra/cicd.md` |
| L — EXPLAIN | | Codebase map: purpose, entry points, core flow, data flow, external deps | "explain this" / new codebase | *(inline — no reference file)* |
| M — TESTGEN | | Post-fix test generation. Complete runnable files only. Never pseudocode. | post-fix / "generate tests" | `references/testing/generator.md` |
| N — DOCGEN | | JSDoc/TSDoc, Python docstrings, Go doc, KDoc, README stubs, OpenAPI snippets | post-fix / "generate docs" | `references/dx/docgen.md` |
| O — UIUX | | 14 sub-scanners: visual, heuristics, states, forms, cognitive load, mobile, animation, dark mode, design system, microcopy, navigation, responsive, delight | frontend code | `references/uiux/index.md` |
| EN — ENHANCE | | 12 sub-enhancers elevating what already works. UX Maturity Score 0–100. | "enhance" / "polish" | `references/enhance/index.md` |
| P — TYPES | | `any` epidemic, missing annotations, unsafe assertions, non-null overuse | TypeScript files | `references/code/type-safety.md` |
| Q — DEADCODE | | Unused exports, unreachable code, dead dependencies, dead CSS | "cleanup" / "unused" | `references/code/tech-debt.md` |
| R — ERRCOV | | Error handling coverage map: % async functions handled, silent failures | "reliability" / async code | `references/code/tech-debt.md` |
| S — COMPLEXITY | | CC per function: 1–5 ok · 6–10 note · 11–15 extract · 16–20 refactor · >20 mandatory split | any function >20 lines | `references/code/tech-debt.md` |
| T — SEO | | Meta tags, OG/Twitter, structured data, noindex bugs, canonical errors | Next.js / Nuxt / SSR | `references/frontend/seo.md` |
| U — OBSERV | | Structured logging, log levels, PII in logs, missing tracing, health check endpoint | production backend | `references/frontend/observability.md` |
| V — BUNDLE | | Barrel file patterns, missing code splitting, heavy dependency alternatives | Webpack / Vite / Next.js | `references/code/bundle.md` |
| W — STATE | | Context re-render, Redux anti-patterns, Zustand pitfalls, server state in Redux | Redux / Zustand / Context | `references/code/state-management.md` |
| X — PWA | | manifest.json completeness, cache strategy audit, offline support | service-worker / manifest | `references/infra/pwa-env.md` |
| Y — ENVCONF | | Startup validation, client bundle exposure, .env.example drift | .env / config files | `references/infra/pwa-env.md` |
| Z — FLAGS | | Stale flag detection, hardcoded booleans, inconsistent names, flag inventory | feature flags / if (FLAG_X) | `references/code/tech-debt.md` |
| AA — APICONTRACT | | Response envelope consistency, HTTP method semantics, status codes | API routes / OpenAPI / fetch | `references/infra/api-contract.md` |
| AB — RATELIMIT | | Missing debounce, double-submit prevention, infinite scroll throttle | search inputs / form submits | `references/infra/api-contract.md` |
| AC — INPUTSANIT | | Path traversal, file upload magic bytes, CSV injection. Dedup with B: AC owns card. | file uploads / user input | `references/security/audit.md` |
| AD — TECHDEBT | | TODO/FIXME inventory, debt heatmap scoring per file | any code | `references/code/tech-debt.md` |
| AE — GDPR | | PII flow mapping, Right to Erasure (Art.17), Minimization, Consent, Retention | user data handling | `references/security/gdpr.md` |
| AF — RESILIENCE | | Timeout, exponential backoff, circuit breaker, graceful degradation, idempotency | external calls | `references/infra/resilience.md` |
| RF — REFACTOR | | Safe step-by-step extraction plan. Activates when CC > 15. | "refactor" / CC > 15 | `references/code/architecture.md` |
| UA — UPGRADE | | Deprecated API detection, modern equivalents, effort + breaking-change assessment | old patterns / legacy code | `references/code/code-review.md` |
| HS — HEALTHSCORE | ✅ | Health Score banner, before/after delta, category weights. Always on. | always (end of session) | `references/session/templates.md` §12 |
| AH — PRDESC | | Structured PR description: What/Why/How/Testing/Breaking/Checklist/Score | post-fix with diff | `references/dx/changelog.md` |
| AI — CHANGELOG | | Versioned changelog: conventional commits parsing, semver bump logic, grouping | "changelog" / commits list | `references/dx/changelog.md` |
| AJ — CROSSFILE | | Pattern drift, naming consistency, type drift, error handling map, API envelope | 2+ files submitted | `references/dx/crossfile.md` |
| AK — VIBECODE | | AI artifact patterns: TODO debris, hallucinated APIs, console.log, `any` epidemic | AI-generated code | `references/dx/vibe-code.md` |
| TQ — TESTQUAL | | Audit existing tests: weak assertions, impl testing, flaky patterns, isolation | test files (*.test.* / *.spec.*) | `references/testing/quality.md` |
| SQ — SCHEMA | | Missing indexes, constraints, audit fields, soft delete inconsistency | SQL schema / ORM models | `references/infra/db-schema.md` |

---

## 4. Scanner Deduplication Map

When two scanners would flag the same issue, this map determines who **owns** the finding card and who adds only a cross-reference note. Never double-report the same line.

| Conflict | Card Owner | Other Scanner Action |
|----------|-----------|---------------------|
| B (Security) + AC (Input Sanitization) flag same input validation issue | **AC owns** | B adds cross-reference note |
| C (Perf) + AF (Resilience) flag same external call | **AF owns** if it's a timeout/retry issue; **C owns** if it's Big-O | Both note the other's angle |
| D (Review) + E (Arch) flag same structural issue | **E owns** if SOLID/layer violation; **D owns** if naming/smell | No double card |
| Q (DeadCode) + AD (TechDebt) flag same unused item | **Q owns** the finding card | AD inventories it in the debt heatmap |
| R (ErrCov) + A (Bug) flag same unhandled async | **A owns** if it's causing a concrete bug; **R owns** if it's a coverage gap | No double card |
| S (Complexity) + RF (Refactor) flag same high-CC function | **S owns** the finding card; **RF owns** the migration plan | Linked by finding ID |
| P (Types) + A (Bug) flag same type error causing crash | **A owns** (bug takes priority) | P adds type annotation fix note |
| T (SEO) + F (A11Y) flag same `<img>` missing alt | **F owns** (accessibility is the primary issue) | T notes SEO implication |
| AA (ApiContract) + AB (RateLimit) flag same form submit | **AA owns** if envelope/status code; **AB owns** if missing debounce | No double card |
| AE (GDPR) + B (Security) flag same PII leak | **AE owns** the finding card | B adds OWASP cross-reference |
| UA (Upgrade) + D (Review) flag same deprecated API | **UA owns** the finding card | D notes code smell aspect |

---

> **Need per-scanner trigger rules, output format, or cross-scanner interactions?**
> → Load `references/scanner-map-detail.md`
