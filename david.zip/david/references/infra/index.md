# DAVID — Infrastructure Reference (Router)

Scanners J, K, H, X, Y, SQ, AF, AA, AB master index. 6 files covering CI/CD, dependencies, resilience, PWA/env config, database schema, and API contracts.

## Which file to load?

| When auditing... | Load |
|------------------|------|
| Dockerfiles, GitHub Actions, database migrations, DDL files | `references/infra/cicd.md` |
| package.json, requirements.txt, lock files, CVE patterns, license conflicts | `references/infra/dependencies.md` |
| External HTTP calls, timeouts, circuit breakers, retry patterns, idempotency | `references/infra/resilience.md` |
| service-worker, manifest.json, .env files, config startup validation | `references/infra/pwa-env.md` |
| SQL schema, ORM models, missing indexes, constraints, audit fields | `references/infra/db-schema.md` |
| API routes, OpenAPI, fetch calls, rate limiting, debounce, double-submit | `references/infra/api-contract.md` |
| **Full infrastructure audit** | **All 6 files** |

## Sub-file Summary

| File | Scanners | Lines | Use Case |
|------|----------|-------|----------|
| `infra/cicd.md` | J — MIGRATE + K — CICD | ~280 | Docker, GitHub Actions, migrations |
| `infra/dependencies.md` | H — DEPS | ~103 | Package security, licenses, abandoned packages |
| `infra/resilience.md` | AF — RESILIENCE | ~421 | Timeout, backoff, circuit breaker, idempotency |
| `infra/pwa-env.md` | X — PWA + Y — ENVCONF | ~189 | PWA manifest, env validation, .env drift |
| `infra/db-schema.md` | SQ — SCHEMA | ~343 | Database schema, indexes, constraints |
| `infra/api-contract.md` | AA — APICONTRACT + AB — RATELIMIT | ~272 | API consistency, rate limiting, debounce |

## Loading Rules

```
Dockerfile / workflow yml   → infra/cicd.md
migration / DDL files       → infra/cicd.md (Scanner J)
package.json / requirements → infra/dependencies.md
external API calls detected → infra/resilience.md
service-worker / manifest   → infra/pwa-env.md
.env / config files         → infra/pwa-env.md
SQL schema / ORM models     → infra/db-schema.md
API routes / fetch calls    → infra/api-contract.md
search inputs / form submit → infra/api-contract.md (Scanner AB)
```
