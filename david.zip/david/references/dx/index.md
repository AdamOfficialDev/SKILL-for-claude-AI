# DAVID — Developer Experience (DX) Reference (Router)

Scanners N, AH, AI, AJ, AK, I master index. 5 files covering documentation generation, changelogs, PR descriptions, cross-file consistency, AI-generated code review, and git diff parsing.

## Which file to load?

| When you need... | Load |
|------------------|------|
| JSDoc/TSDoc, Python docstrings, KDoc, README stubs, OpenAPI snippets | `references/dx/docgen.md` |
| PR descriptions (What/Why/How/Testing/Breaking/Checklist) | `references/dx/changelog.md` |
| Versioned changelogs, conventional commits, semver bump logic | `references/dx/changelog.md` |
| Pattern drift, naming consistency, type drift across 2+ files | `references/dx/crossfile.md` |
| AI-generated / Copilot code: TODO debris, hallucinated APIs, `any` epidemic | `references/dx/vibe-code.md` |
| Git diff parsing, change map, cross-file impact, regression detection | `references/dx/git-diff.md` |
| **Full DX session** | **All 5 files** |

## Sub-file Summary

| File | Scanners | Lines | Use Case |
|------|----------|-------|----------|
| `dx/docgen.md` | N — DOCGEN | ~474 | Post-fix documentation; Tier 3+ only |
| `dx/changelog.md` | AH — PRDESC + AI — CHANGELOG | ~436 | PR descriptions + versioned changelogs |
| `dx/crossfile.md` | AJ — CROSSFILE | ~473 | 2+ files submitted; consistency audit |
| `dx/vibe-code.md` | AK — VIBECODE | ~599 | AI/Copilot code verification |
| `dx/git-diff.md` | I — GIT | ~447 | Git diff submitted as input |

## Loading Rules

```
post-fix (Tier 3+)           → dx/docgen.md
"changelog" / commits list   → dx/changelog.md
post-fix with diff           → dx/changelog.md (AH — PRDESC)
2+ files submitted           → dx/crossfile.md
AI-generated code detected   → dx/vibe-code.md
git diff submitted           → dx/git-diff.md
```

> Skip `dx/docgen.md` for Tier 1–2 — run only on Tier 3+ or explicit user request.
