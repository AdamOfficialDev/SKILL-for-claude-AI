# DAVID v6.0 — Session Templates Reference

**Phase 5+ file.** Load at start of Phase 5 (Five-Tier Verification) and keep loaded through Phase 9.
Contains: Finding report cards, change plan, five-tier verification, loop exhausted protocol, health score, final summary, delivery safety gate, linter gate protocol.

---

## Table of Contents
8.  [Finding Report Card Templates](#8-finding-report-card-templates)
9.  [Change Plan Template](#9-change-plan-template)
10. [Five-Tier Verification](#10-five-tier-verification)
11. [Loop Exhausted Protocol](#11-loop-exhausted-protocol)
12. [Code Health Score (Scanner HS)](#12-code-health-score-scanner-hs)
13. [Final Session Summary](#13-final-session-summary)
14. [Delivery Safety Gate](#14-delivery-safety-gate)
15. [Linter Gate Protocol](#15-linter-gate-protocol)

---


## 8. Finding Report Card Templates

Every finding output by any scanner **must** use these templates exactly.
**Format Law:** No markdown tables. No prose paragraphs. No improvised formats. If a template exists here, use it.

### Base Finding Card (all scanners)

```
┌─ [SCANNER-CODE]-[NNN] · [PRIORITY] ──────────────────────────────┐
│ File       : [filename]:[line number]                             │
│ Root       : [root cause — one precise sentence]                  │
│ Impact     : [what breaks or what's at risk if this is not fixed] │
│ Fix Mode   : [SAFE TO APPLY / REVIEW FIRST / CONFIRM BEFORE]     │
│ Confidence : [XX%]                                                │
└───────────────────────────────────────────────────────────────────┘

**Before:**
```[lang]
[exact lines as they are — full context, not truncated]
```

**After (DAVID Fix [SCANNER-CODE]-[NNN]):**
```[lang]
[complete fixed file or function — never partial snippets]
// DAVID FIX [SCANNER-CODE]-[NNN]: [one-line explanation of what changed and why]
```
```

**Finding ID format:** `[SCANNER]-[NNN]` — e.g. `BUG-001`, `SEC-003`, `PERF-007`, `UX-012`, `ARCH-001`, `DEBT-004`

**Priority values:** `P0 CRITICAL` · `P1 HIGH` · `P2 MEDIUM` · `P3 LOW` · `SEC` · `ARCH` · `DEBT`

**Fix Mode values and when to use them:**
| Fix Mode | When | Behavior |
|----------|------|----------|
| `SAFE TO APPLY` | Isolated change, no side effects, not business logic | Apply immediately without asking |
| `REVIEW FIRST` | Touches business logic, valid alternatives exist, cross-file change | Show fix, ask user to confirm before applying |
| `CONFIRM BEFORE` | Architectural, breaking change, payment/auth/deletion, confidence < 70% | Must get explicit confirmation — never auto-apply |

### SEC Finding Card (Scanner B + AC)

Extends base card with mandatory security fields:

```
┌─ SEC-[NNN] · SEC ─────────────────────────────────────────────────┐
│ File       : [filename]:[line]                                     │
│ Root       : [vulnerability description — precise and technical]   │
│ Impact     : [what an attacker can do if this is exploited]        │
│ OWASP      : [A0X:YYYY — category name]                           │
│ CVSS Est   : [N.N] — [LOW / MEDIUM / HIGH / CRITICAL]             │
│ CVE Ref    : [CVE-YYYY-NNNNN if known, or "N/A"]                  │
│ Fix Mode   : CONFIRM BEFORE  (security changes always require confirmation) │
│ Confidence : [XX%]                                                 │
└────────────────────────────────────────────────────────────────────┘
```

**Deduplication:** When both B and AC flag the same input validation issue → AC owns the card, B adds only a cross-reference note. Never double-report the same line.

> 📂 Complete deduplication rules for all 11 scanner conflict pairs: `references/scanner-map.md` § 4. Scanner Deduplication Map

### UX Finding Card (Scanner O)

Extends base card with UX-specific fields:

```
┌─ UX-[NNN] · [P1/P2/P3] ──────────────────────────────────────────┐
│ File        : [filename]:[line]                                    │
│ Component   : [component or UI element name]                       │
│ Root        : [UX issue description — specific and actionable]     │
│ UX Impact   : [P1 — broken/missing · P2 — poor experience · P3 — improvement] │
│ Sub-Scanner : [O1–O14 code — e.g. O4 Form UX, O6 Mobile Touch]   │
│ Fix Mode    : [SAFE TO APPLY / REVIEW FIRST]                      │
│ Confidence  : [XX%]                                                │
└────────────────────────────────────────────────────────────────────┘
```

### ARCH Finding Card (Scanner E)

```
┌─ ARCH-[NNN] · ARCH ───────────────────────────────────────────────┐
│ File        : [filename]:[line]                                    │
│ Pattern     : [SOLID violation / coupling issue / anti-pattern]    │
│ Root        : [structural problem description]                     │
│ Impact      : [maintainability / scalability / testability risk]   │
│ Scope       : [isolated file / cross-module / system-wide]         │
│ Fix Mode    : CONFIRM BEFORE  (architectural changes always require confirmation) │
│ Confidence  : [XX%]                                                │
└────────────────────────────────────────────────────────────────────┘

**Proposed refactor (propose only — do NOT apply without explicit confirmation):**
1. [Step one — specific and safe]
2. [Step two]
3. [Step N]
```

### PERF Finding Card (Scanner C)

Extends base card with performance metrics:

```
┌─ PERF-[NNN] · [P1/P2] ────────────────────────────────────────────┐
│ File         : [filename]:[line]                                    │
│ Root         : [algorithmic or structural cause]                    │
│ Complexity   : [Before: O(n²) → After: O(n log n)]                │
│ Est. Impact  : [~Xms per request / X% memory reduction / X% CPU]  │
│ Fix Mode     : [SAFE TO APPLY / REVIEW FIRST]                      │
│ Confidence   : [XX%]                                               │
└─────────────────────────────────────────────────────────────────────┘
```

### DEBT Finding Card (Scanners AD / Q / R / S / Z)

```
┌─ DEBT-[NNN] · DEBT ────────────────────────────────────────────────┐
│ File         : [filename]:[line]                                    │
│ Type         : [TODO debris / dead code / CC score / stale flag / error gap] │
│ Root         : [description of the debt item]                       │
│ CC Score     : [N — only if complexity finding; omit otherwise]     │
│ Debt Priority: [High / Medium / Low — based on blast radius + frequency] │
│ Fix Mode     : [SAFE TO APPLY / REVIEW FIRST]                       │
│ Confidence   : [XX%]                                                │
└─────────────────────────────────────────────────────────────────────┘
```

### Batch Finding Header (3+ findings of same scanner)

When a scanner produces 3 or more findings, wrap with a batch header and footer:

```
━━ [SCANNER-CODE] FINDINGS — [N] issues · [Highest priority] ━━━━━━━━
[Card 1]
[Card 2]
...
[Card N]
━━ END [SCANNER-CODE] — [N] fixed, [M] need confirmation ━━━━━━━━━━━━
```

---

## 9. Change Plan Template

Required **before** applying fixes in Phase 3. Output this block before every fix batch without exception — even for single-finding sessions.

```
📋 DAVID CHANGE PLAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Issues Found   : [N]
Auto-Fixing    : [N] (SAFE TO APPLY)
Review First   : [N] (REVIEW FIRST — see [IDs])
Needs Confirm  : [N] (CONFIRM BEFORE — see [IDs])

MANIFEST:
| FILE             | LINE  | ACTION                    | SCANNER | MODE     |
|------------------|-------|---------------------------|---------|----------|
| [filename]       | [N]   | MODIFY                    | [code]  | SAFE     |
| [filename]       | [N]   | ADD                       | [code]  | SAFE     |
| [filename]       | [N]   | DELETE (CONFIRM REQUIRED) | [code]  | CONFIRM  |
| [filename]       | [N]   | RENAME (CONFIRM REQUIRED) | [code]  | CONFIRM  |

UNTOUCHED GUARANTEE: All other lines in all files remain byte-for-byte identical.
* DELETE and RENAME always require explicit user confirmation — never auto-apply.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Execution rules:**
- Every finding that results in any code change requires a MANIFEST row — no exceptions
- `ACTION` values: `MODIFY` · `ADD` · `DELETE (CONFIRM REQUIRED)` · `RENAME (CONFIRM REQUIRED)`
- If `david: apply all` is active, warn before executing: `⚠️ david: apply all active — all CONFIRM items will be applied. Proceeding...`
- Code surgery: preserve all indentation, whitespace, comments, imports, variable names unchanged
- Annotate every changed line inline: `// DAVID FIX [FINDING-ID]: [explanation]`
- Output complete files — never partial snippets unless `david: diff only` is active

---

## 10. Five-Tier Verification

Run after every fix batch in Phase 5. All 5 tiers must pass before delivery.

**If any tier FAILS:**
1. Stop immediately at the failing tier — do not continue to the next tier
2. Identify the regression the fix introduced
3. Adjust the fix — do not re-apply the original broken code
4. Re-verify the failing tier specifically first
5. Re-run all 5 tiers from Tier 1 again
6. Deliver only after all 5 tiers show PASS

### Verification Banner

```
🧪 DAVID VERIFICATION — Iteration [N]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Tier 1 Logic          [PASS / FAIL — describe regression if FAIL]
Tier 2 Integrity      [PASS / FAIL — describe regression if FAIL]
Tier 3 Integration    [PASS / FAIL — describe regression if FAIL]
Tier 4 Security       [PASS / FAIL — describe regression if FAIL]
Tier 5 Non-Functional [PASS / FAIL — describe regression if FAIL]
Overall: [CLEAN / FAIL — re-verifying Tier N]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Tier Definitions

| Tier | Checks |
|------|--------|
| 1 Logic | The failing input now passes; null/empty/boundary inputs handled; happy path unchanged |
| 2 Integrity | Output file has equal or more lines than input; no functions/classes/exports removed without authorization |
| 3 Integration | All callers and callees of changed code are compatible; type contracts unchanged or explicitly updated |
| 4 Security | Diff introduces no new injection vector, no secret exposure, no permission escalation, no OWASP regression |
| 5 Non-Functional | No new O(n²) loops; no new synchronous blocking; no accessibility or UX regressions introduced |

---

## 11. Loop Exhausted Protocol

Activates when iteration 5 completes and issues still remain unresolved.
**DAVID does not silently stop.** Output this block in full:

```
⚠️ DAVID LOOP EXHAUSTED — 5/5 passes complete.
   [N] issues resolved. [M] issues remain unresolvable in current session.

REMAINING ISSUES:
  [FINDING-ID] [PRIORITY] — [Description]
  Root cause    : [architectural / cross-system / requires human decision]
  Recommended   : [specific next step — actionable]

REASON NOT AUTO-FIXED (check all that apply):
  □ Requires architectural decision     → escalate to ARCH review
  □ Business logic ambiguity            → confirm intent with product/team
  □ Cross-system dependency             → coordinate with dependent service owner
  □ Breaking change risk                → staged rollout required
  □ Confidence too low to auto-fix      → run: david: explain [FINDING-ID]
```

**Automatic escalation after output:**
- P0 / P1 / SEC remaining → flagged as **SHIP BLOCKER** in Final Session Summary and Delivery Safety Gate
- P2 / P3 / ARCH / DEBT remaining → added to Tech Debt Heatmap with priority ranking
- Phase 9 Health Score still runs — remaining issues count against final score with full transparency

---

## 12. Code Health Score (Scanner HS)

Always runs. Activates at end of every session automatically.
Cannot be disabled unless user explicitly commands `david: no health score`.

### Score Banner

```
╔══════════════════════════════════════════════════════════════════╗
║           🏥 DAVID v6.0 CODE HEALTH SCORE                        ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  BEFORE  ████████████░░░░░░░░  [N]/100                           ║
║  AFTER   ███████████████████░  [N]/100  (+[delta]) [🎉 if ≥+10] ║
║                                                                  ║
╠══════════════════════════════════════════════════════════════════╣
║  Category Scores (0–100 each):                                   ║
║  🔍 Bug-Free          : [N]/100  (weight: 20%)                   ║
║  🔐 Security          : [N]/100  (weight: 20%)                   ║
║  🔏 Privacy/GDPR      : [N]/100  (weight: 10%)                   ║
║  📊 Performance       : [N]/100  (weight: 12%)                   ║
║  🎨 UI/UX Quality     : [N]/100  (weight: 10%)                   ║
║  🧪 Test Quality      : [N]/100  (weight: 10%)                   ║
║  🛡️  Resilience        : [N]/100  (weight:  8%)                   ║
║  🗄️  Schema Quality    : [N]/100  (weight:  5%)                   ║
║  🤝 Code Quality      : [N]/100  (weight:  3%)                   ║
║  🔷 Type Safety       : [N]/100  (weight:  2%)                   ║
╠══════════════════════════════════════════════════════════════════╣
║  Top 3 issues still open (if any):                               ║
║  1. [FINDING-ID] [description] — [reason still open]             ║
║  2. [FINDING-ID] [description] — [reason still open]             ║
║  3. [FINDING-ID] [description] — [reason still open]             ║
║  (omit this block entirely if all findings resolved)             ║
╚══════════════════════════════════════════════════════════════════╝
```

### Score Computation Rules

- **Before score**: estimated from severity and count of all findings detected before any fixes applied
- **After score**: recalculated after all verified fixes in the Phase 4 loop
- **Delta**: after − before. Add 🎉 if delta ≥ +10
- **Score bands**: 90–100 Excellent · 75–89 Good · 60–74 Needs Work · <60 Critical
- **Remaining issues**: included in "Top 3 open" — never hidden from score

### Category Weight Rationale

| Category | Weight | Rationale |
|----------|--------|-----------|
| Bug-Free | 20% | Bugs directly break functionality users rely on |
| Security | 20% | Security failures can be catastrophic and irreversible |
| Privacy/GDPR | 10% | Legal exposure + user trust erosion |
| Performance | 12% | Directly impacts user experience and infrastructure cost |
| UI/UX Quality | 10% | Determines if product is actually usable by humans |
| Test Quality | 10% | Determines confidence in all future changes |
| Resilience | 8% | Production stability under partial failure conditions |
| Schema Quality | 5% | Data integrity is the foundation everything else runs on |
| Code Quality | 3% | Long-term maintainability |
| Type Safety | 2% | Catch errors at compile time, not in production |

---

## 13. Final Session Summary

Output at end of every Tier 3+ session, immediately after the Health Score banner:

```
╔══════════════════════════════════════════════════════════════════╗
║             🤖 DAVID v6.0 — FINAL REPORT                         ║
╠══════════════════════════════════════════════════════════════════╣
║  Session    : DAVID-[id]   │  Iterations: [N]/5                  ║
╠═══════════════════════════╦══════════════════════════════════════╣
║  CORE SCANNERS            ║  EXTENDED SCANNERS                   ║
║  🐛 Bugs      : [N]→[N]  ║  🧪 Test Quality : [N]→[N]          ║
║  🔐 Security  : [N]→[N]  ║  🔏 GDPR/Privacy : [N]→[N]          ║
║  📊 Perf      : [N]→[N]  ║  🛡️  Resilience   : [N]→[N]          ║
║  🎨 UI/UX     : [N]→[N]  ║  🗄️  DB Schema    : [N]→[N]          ║
║  🤝 Review    : [N]→[N]  ║  📡 Observ.      : [N]→[N]          ║
║  🏛️  Arch      : proposed ║  🔍 SEO          : [N]→[N]          ║
║  ♿ A11Y      : [N]→[N]  ║  🎯 Vibe Code    : [N]→[N]          ║
║  🔷 Types     : [N]→[N]  ║  📦 Bundle       : [N]→[N]          ║
╠═══════════════════════════╩══════════════════════════════════════╣
║  DX LAYER                                                        ║
║  📝 Tests generated      : [N cases across N files]              ║
║  📄 Docs updated         : [N functions with JSDoc/TSDoc]        ║
║  🗺️  Tech debt items      : [N inventoried, N resolved]           ║
║  ⬆️  Upgrade suggestions   : [N patterns identified]              ║
║  🔀 Cross-file consistency: [N drift issues · score: N/100]      ║
║  📝 PR description        : [Generated / N/A — no diff]          ║
║  📋 Changelog             : [Generated / N/A — no release]       ║
╠══════════════════════════════════════════════════════════════════╣
║  📁 Files Modified  : [list all filenames]                       ║
║  ➕ Lines Added     : [N]  ✏️  Modified: [N]  ❌ Unauthorized del: 0 ║
╠══════════════════════════════════════════════════════════════════╣
║  🏥 HEALTH SCORE: [N] → [N] (+[delta])                          ║
║  ✅ STATUS: VERIFIED CLEAN — Safe to deploy                      ║
║  (or: ⚠️  SHIP BLOCKER — [N] unresolved P0/P1/SEC findings)     ║
╚══════════════════════════════════════════════════════════════════╝
```

**Row format rules:**
- `[N]→[N]` = findings detected before → findings remaining after (e.g. `3→0` means all fixed)
- `Unauthorized del: 0` is always 0 — if it would be nonzero, DAVID has violated Inviolable Law #1
- Omit DX rows that are `N/A` only for Tier 2 sessions (DX layer is optional at Tier 2)
- SHIP BLOCKER status overrides VERIFIED CLEAN — if any P0/P1/SEC remain open, show blocker line

---

## 14. Delivery Safety Gate

Runs at the very end of every session, before the Final Session Summary.
Every checkbox must be verified. If any item cannot be `✅`, output `❌` and explain why.
Items marked `[TIER 3+ ONLY]` auto-skip (mark `[—]`) for Tier 1 and Tier 2 sessions.
Items marked `[SKIP: USER CMD]` auto-skip when the user has issued the corresponding override command.

```
🚀 DAVID v6.0 DELIVERY SAFETY GATE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[✅/❌]    All findings have report cards  (§8 templates used)
[✅/❌]    Change Plan followed exactly  (§9 — every changed line in MANIFEST)
[✅/❌]    Zero unauthorized deletions  (Inviolable Law #1)
[✅/❌]    Zero unrelated code altered  (Inviolable Law #4)
[✅/❌/—]  Cross-file propagation complete  (Scanner AJ verified) [TIER 3+ ONLY]
[✅/❌]    Complete files provided  (no partial snippets)
[✅/❌]    All 5 verification tiers passed  (§10 — Overall: CLEAN)
[✅/❌/⚠️] Linter Gate passed  (§15 — zero lint errors; mode: REAL or SIMULATED stated)
[✅/❌/—]  Tests generated for all fixed issues  (Scanner M) [TIER 3+ ONLY]
[✅/❌/—]  Docstrings updated on all touched functions  (Scanner N — @davidfix tag) [TIER 3+ ONLY]
[✅/❌/—]  Tech Debt Heatmap generated  (Scanner AD) [TIER 3+ ONLY]
[✅/❌/—]  Code Health Score calculated  (Scanner HS — §12) [TIER 3+ ONLY — skippable via `no health score`]
[✅/❌/—]  PR Description generated if diff available  (Scanner AH) [TIER 3+ ONLY]
[✅/❌]    Safe to replace old files and open PR

Legend: ✅ = passed  ❌ = SHIP BLOCKER  — = auto-skipped (tier or command)  ⚠️ = skipped by user

FINAL STATUS: [✅ VERIFIED CLEAN — Safe to deploy]
              [⚠️  SHIP BLOCKER — [N] unresolved critical findings — do NOT deploy]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 15. Linter Gate Protocol

Runs as **Phase 5.5** — mandatory after every Phase 5 CLEAN, before any file is delivered.
No file reaches the user unless this gate passes or is explicitly marked SIMULATED with reason.

### Step 1 — Config Detection (check project root in order)

| Config File | Tool | Command |
|-------------|------|---------|
| `eslint.config.*` / `.eslintrc*` | ESLint | `npx eslint . --max-warnings 0` |
| `biome.json` | Biome | `npx biome check .` |
| `tsconfig.json` | TypeScript | `npx tsc --noEmit` |
| `.prettierrc*` / `prettier.config.*` | Prettier | `npx prettier --check .` |
| `pyproject.toml` / `setup.cfg` / `.flake8` | Ruff / Flake8 | `ruff check . && ruff format --check .` OR `flake8 .` |
| `.rubocop.yml` / `.rubocop*` | RuboCop | `bundle exec rubocop --no-color` |
| `.golangci.yml` / `.golangci*` | golangci-lint | `golangci-lint run ./...` |
| `*.sh` files present | ShellCheck | `shellcheck **/*.sh` |
| None detected | — | Output `⚠️ NO LINTER CONFIG DETECTED` — recommend adding one, proceed |

Multiple configs may coexist (e.g. ESLint + tsc + Prettier) — run ALL detected tools.

### Step 2 — Execution Mode

**REAL EXECUTION** — when `bash_tool` is available:
```
Run the exact command string. Capture stdout + stderr.
Parse exit code: 0 = CLEAN, non-zero = FAIL.
Show actual tool output verbatim in the banner.
```

**SIMULATED** — when no terminal access (Claude.ai):
```
Mentally re-scan every changed line against the detected ruleset.
Check: unused vars, missing types, wrong imports, formatting, rule violations.
State confidence % explicitly.
Banner MUST include: 🤖 SIMULATED LINT (no terminal access)
```

### Step 3 — Outcome Enforcement

```
LINT CLEAN  → proceed to Phase 6
LINT FAIL   → BLOCK DELIVERY immediately
              ├── List every error: file:line — rule — description
              ├── Fix each error (respect Law #4 — minimal blast radius)
              ├── Re-run Phase 5 Tier 1 + Tier 2
              └── Re-run Linter Gate
              → Lint fix iterations count against Phase 4 loop counter (max 5 total)
              → If loop exhausted with lint errors remaining → SHIP BLOCKER in §14
```

### Linter Gate Output Banner (required every time)

```
🔍 DAVID LINTER GATE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Config detected : [eslint | tsc | biome | prettier | ruff | rubocop | golangci | shellcheck | none]
Mode            : [REAL EXECUTION | 🤖 SIMULATED — no terminal — confidence XX%]
Command(s) run  : [exact command string(s)]
Files checked   : [N files]
Result          : [✅ LINT CLEAN — 0 errors, 0 warnings | ❌ LINT FAIL — N errors, M warnings]

[If FAIL — list each issue:]
  [file]:[line]  [rule-id]  [description]

Action          : [Proceeding to Phase 6 | ⛔ DELIVERY BLOCKED — fixing lint errors]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Edge Cases

| Situation | Behaviour |
|-----------|-----------|
| Lint config exists but tool not installed | Declare `⚠️ TOOL NOT INSTALLED: [tool]` — switch to SIMULATED mode |
| Only warnings, zero errors | `LINT CLEAN` — list warnings in banner as FYI, do not block |
| `--max-warnings 0` causes fail on warnings | Treat as FAIL — fix warnings too |
| User runs `david: skip lint` | Allowed — record exception in session state, mark Safety Gate item `[⚠️ SKIPPED BY USER]` |
| Tier 1–2 quick sessions | Linter Gate still runs — it only takes a moment and catches real breakage |
