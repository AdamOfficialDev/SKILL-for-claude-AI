# DAVID — Session Management Reference (Router)

Session lifecycle master index. 4 files governing DAVID's runtime state, commands, templates, and protocol routing.

## Which file to load?

| When you need... | Load |
|------------------|------|
| **Always-on** — lifecycle, state tracker, continuation, memory, fingerprint, file request | `references/session/core.md` ← START HERE |
| Override commands, finding management, export, format, mode, history | `references/session/commands.md` |
| Finding report cards, verification tiers, health score, linter gate, safety gate | `references/session/templates.md` |
| Protocol routing table (which file handles what) | `references/session/protocols.md` |

## Sub-file Summary

| File | Sections | Lines | When to Load |
|------|----------|-------|-------------|
| `session/core.md` | Lifecycle, state, continuation, fingerprint, file request | ~277 | **Always** — every session |
| `session/commands.md` | All `david:` commands, scope, findings, export, format, modes | ~562 | First `david:` command or end of Phase 1 |
| `session/templates.md` | Report cards, change plan, verification, health score, gates | ~480 | Phase 1 start — keep loaded through Phase 9 |
| `session/protocols.md` | Routing table for all session protocols | ~17 | Reference only |

## Loading Rules

```
Phase 1 start  → session/core.md (always)
Phase 1 end    → session/commands.md (pre-load)
First david:   → session/commands.md (if not already loaded)
Phase 5 start  → session/templates.md (keep through Phase 9)
```

> ⚠️  `session/core.md` is the ONLY always-on session file. Load others on-demand per the rules above.
