# DAVID v6.0 — Session Templates Reference

**Load at session start (Phase 1) — keep loaded through Phase 9.**
Finding Report Cards (§8) are output at Phase 3. Templates must be in context before Phase 3 begins.
Contains: Finding report cards, change plan, five-tier verification, loop exhausted protocol, health score, final summary, delivery safety gate, linter gate protocol.

---

## Table of Contents
8.  [Finding Report Card Templates](#8-finding-report-card-templates)
9.  [Change Plan Template](#9-change-plan-template)
10. [Five-Tier Verification](#10-five-tier-verification)
11. [Loop Exhausted Protocol](#11-loop-exhausted-protocol)
12. [Code Health Score (Scanner HS)](#12-code-health-score-scanner-hs)
13. [Final Session Summary](#13-final-session-summary)
14. [Delivery Safety Gate](#14-delivery-safety-gate)
15. [Linter Gate Protocol](#15-linter-gate-protocol)

---

## Design System

All DAVID output blocks follow a unified visual language:

| Element | Style |
|---------|-------|
| Block header | `━━━ 🔤 TITLE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━` |
| Section divider | `─────────────────────────────────────────────────` |
| Finding card | `┌─ ID · PRIORITY ──────┐ │ fields │ └─────────────┘` |
| Key-value rows | aligned with `:` — label padded to consistent width |
| Status icons | `✅` pass · `❌` fail/blocker · `⚠️` warning · `—` skipped |

**Format Law:** No markdown tables, no prose substitutions, no improvised formats.
Use exact templates below — every field, every separator, every emoji.

---

## 8. Finding Report Card Templates

Every finding output by any scanner **must** use these templates exactly.

### Base Finding Card

```
┌─ [SCANNER]-[NNN] · [PRIORITY] ──────────────────────────────────────┐
│  File       : [filename]:[line]                                      │
│  Root       : [root cause — one precise sentence]                    │
│  Impact     : [what breaks or what's at risk if not fixed]           │
│  Fix Mode   : [SAFE TO APPLY / REVIEW FIRST / CONFIRM BEFORE]        │
│  Confidence : [XX%]                                                  │
└──────────────────────────────────────────────────────────────────────┘

**Before:**
```[lang]
[exact lines as they are — full context, not truncated]
```

**After — DAVID Fix [SCANNER]-[NNN]:**
```[lang]
[complete fixed file or function — never partial snippets]
// DAVID FIX [SCANNER]-[NNN]: [one-line explanation of what changed and why]
```
```

**Finding ID format:** `[SCANNER]-[NNN]` e.g. `BUG-001` · `SEC-003` · `PERF-007` · `UX-012` · `ARCH-001` · `DEBT-004`

**Priority values:** `P0 CRITICAL` · `P1 HIGH` · `P2 MEDIUM` · `P3 LOW` · `SEC` · `ARCH` · `DEBT`

**Fix Mode:**
- `SAFE TO APPLY` — isolated change, no side effects, not business logic → apply immediately
- `REVIEW FIRST` — touches business logic or cross-file → show fix, user confirms before applying
- `CONFIRM BEFORE` — architectural / breaking / payment / auth / deletion, confidence < 70% → never auto-apply

---

### SEC Finding Card (Scanner B + AC)

```
┌─ SEC-[NNN] · SEC ────────────────────────────────────────────────────┐
│  File       : [filename]:[line]                                      │
│  Root       : [vulnerability — precise and technical]                │
│  Impact     : [what an attacker can do if this is exploited]         │
│  OWASP      : [A0X:YYYY — category name]                            │
│  CVSS Est   : [N.N] · [LOW / MEDIUM / HIGH / CRITICAL]              │
│  CVE Ref    : [CVE-YYYY-NNNNN if known, or "N/A"]                   │
│  Fix Mode   : CONFIRM BEFORE  ← security changes always require confirmation │
│  Confidence : [XX%]                                                  │
└──────────────────────────────────────────────────────────────────────┘
```

> Dedup rule: when B + AC flag same input validation issue → AC owns the card, B adds cross-reference only.
> Full dedup rules → `references/scanner-map.md` §4.

---

### PERF Finding Card (Scanner C)

```
┌─ PERF-[NNN] · [P1/P2] ───────────────────────────────────────────────┐
│  File        : [filename]:[line]                                      │
│  Root        : [algorithmic or structural cause]                      │
│  Complexity  : [Before: O(n²) → After: O(n log n)]                   │
│  Est. Impact : [~Xms per request / X% memory / X% CPU reduction]     │
│  Fix Mode    : [SAFE TO APPLY / REVIEW FIRST]                         │
│  Confidence  : [XX%]                                                  │
└───────────────────────────────────────────────────────────────────────┘
```

---

### UX Finding Card (Scanner O)

```
┌─ UX-[NNN] · [P1/P2/P3] ─────────────────────────────────────────────┐
│  File        : [filename]:[line]                                      │
│  Component   : [component or UI element name]                         │
│  Root        : [UX issue — specific and actionable]                   │
│  UX Impact   : [P1 broken/missing · P2 poor experience · P3 polish]  │
│  Sub-Scanner : [O1–O14 — e.g. O4 Form UX · O6 Mobile Touch]         │
│  Fix Mode    : [SAFE TO APPLY / REVIEW FIRST]                         │
│  Confidence  : [XX%]                                                  │
└──────────────────────────────────────────────────────────────────────┘
```

---

### ARCH Finding Card (Scanner E)

```
┌─ ARCH-[NNN] · ARCH ──────────────────────────────────────────────────┐
│  File        : [filename]:[line]                                      │
│  Pattern     : [SOLID violation / coupling issue / anti-pattern]      │
│  Root        : [structural problem description]                       │
│  Impact      : [maintainability / scalability / testability risk]     │
│  Scope       : [isolated file / cross-module / system-wide]           │
│  Fix Mode    : CONFIRM BEFORE  ← architectural changes always require confirmation │
│  Confidence  : [XX%]                                                  │
└──────────────────────────────────────────────────────────────────────┘

Proposed refactor (PROPOSE ONLY — never auto-apply):
  Step 1 : [specific extraction — name + what to move]
  Step 2 : [next extraction]
  Step N : [final state + test strategy]
  Effort : [Low / Med / High]   Breaking risk : [None / Low — update N callers]
```

---

### DEBT Finding Card (Scanners Q / R / S / Z / AD)

```
┌─ DEBT-[NNN] · DEBT ──────────────────────────────────────────────────┐
│  File         : [filename]:[line]                                     │
│  Type         : [TODO debris / dead code / CC score / stale flag / error gap] │
│  Root         : [description of the debt item]                        │
│  CC Score     : [N — only if complexity finding; omit otherwise]      │
│  Debt Priority: [High / Medium / Low — based on blast radius + frequency] │
│  Fix Mode     : [SAFE TO APPLY / REVIEW FIRST]                        │
│  Confidence   : [XX%]                                                 │
└──────────────────────────────────────────────────────────────────────┘
```

---

### Batch Finding Header (3+ findings from same scanner)

```
━━━ [SCANNER] FINDINGS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [N] issues · highest priority: [PRIORITY]
─────────────────────────────────────────────────────────────────────
[Card 1]
[Card 2]
...
[Card N]
─────────────────────────────────────────────────────────────────────
  [N] fixed · [M] need confirmation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 9. Change Plan Template

Required **before** applying any fix in Phase 3. Output before every fix batch — no exceptions, even single-finding sessions.

```
━━━ 📋 DAVID CHANGE PLAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Issues Found  : [N]
  Auto-Fixing   : [N] (SAFE TO APPLY)
  Review First  : [N] (REVIEW FIRST — IDs: [list])
  Needs Confirm : [N] (CONFIRM BEFORE — IDs: [list])
─────────────────────────────────────────────────────────────────────
  MANIFEST
  File                  Ln    Action                  Scanner  Mode
  ─────────────────     ────  ──────────────────────  ───────  ───────
  [filename]            [N]   MODIFY                  [code]   SAFE
  [filename]            [N]   ADD                     [code]   SAFE
  [filename]            [N]   DELETE (CONFIRM REQ.)   [code]   CONFIRM
  [filename]            [N]   RENAME (CONFIRM REQ.)   [code]   CONFIRM
─────────────────────────────────────────────────────────────────────
  UNTOUCHED GUARANTEE: all other lines remain byte-for-byte identical.
  DELETE and RENAME always require explicit user confirmation.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Execution rules:**
- Every finding that results in a code change requires a MANIFEST row — no exceptions
- `ACTION` values: `MODIFY` · `ADD` · `DELETE (CONFIRM REQUIRED)` · `RENAME (CONFIRM REQUIRED)`
- If `david: apply all` is active → warn first: `⚠️ david: apply all active — all CONFIRM items will be applied. Proceeding...`
- Preserve all indentation, whitespace, comments, imports, variable names unchanged
- Annotate every changed line inline: `// DAVID FIX [FINDING-ID]: [explanation]`
- Output complete files — never partial snippets unless `david: diff only` is active

---

## 10. Five-Tier Verification

Run after every fix batch in Phase 5. All 5 tiers must pass before delivery.

**If any tier FAILS:** stop at the failing tier → identify regression → adjust fix → re-verify that tier → re-run all 5 tiers → deliver only after all show PASS.

```
━━━ 🧪 DAVID VERIFICATION — Iteration [N]/5 ━━━━━━━━━━━━━━━━━━━━━━━━━━
  Tier 1  Logic          [✅ PASS / ❌ FAIL — describe regression]
  Tier 2  Integrity      [✅ PASS / ❌ FAIL — describe regression]
  Tier 3  Integration    [✅ PASS / ❌ FAIL — describe regression]
  Tier 4  Security       [✅ PASS / ❌ FAIL — describe regression]
  Tier 5  Non-Functional [✅ PASS / ❌ FAIL — describe regression]
─────────────────────────────────────────────────────────────────────
  Overall : [✅ CLEAN — proceeding to Phase 5.5 / ❌ FAIL — re-verifying Tier N]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Tier definitions:**

| Tier | What is checked |
|------|----------------|
| 1 Logic | Failing input now passes; null/empty/boundary handled; happy path unchanged |
| 2 Integrity | Line count ≥ input; no functions/classes/exports removed without authorization |
| 3 Integration | All callers/callees compatible; type contracts unchanged or explicitly updated |
| 4 Security | No new injection vector, no secret exposure, no permission escalation, no OWASP regression |
| 5 Non-Functional | No new O(n²) loops; no new blocking; no a11y/UX regressions introduced |

---

## 11. Loop Exhausted Protocol

Activates when iteration 5 completes and issues still remain. **DAVID never silently stops.**

```
━━━ ⚠️  DAVID LOOP EXHAUSTED ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  5/5 passes complete.
  [N] issues resolved.  [M] issues remain unresolvable in this session.
─────────────────────────────────────────────────────────────────────
  REMAINING ISSUES
  [FINDING-ID] · [PRIORITY] — [description]
    Root cause  : [architectural / cross-system / requires human decision]
    Recommended : [specific next step — actionable]
─────────────────────────────────────────────────────────────────────
  REASON NOT AUTO-FIXED
  □ Requires architectural decision     → escalate to ARCH review
  □ Business logic ambiguity            → confirm intent with product/team
  □ Cross-system dependency             → coordinate with dependent service owner
  □ Breaking change risk                → staged rollout required
  □ Confidence too low to auto-fix      → run: david: explain [FINDING-ID]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Automatic escalation after output:**
- P0 / P1 / SEC remaining → flagged **SHIP BLOCKER** in §13 and §14
- P2 / P3 / ARCH / DEBT remaining → added to Tech Debt Heatmap with priority ranking
- Health Score (§12) still runs — remaining issues count against final score with full transparency

---

## 12. Code Health Score (Scanner HS)

Always runs at end of every session. Cannot be disabled unless `david: no health score` is active.

```
━━━ 🏥 DAVID v6.0 — CODE HEALTH SCORE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  BEFORE  ████████████░░░░░░░░  [N]/100
  AFTER   ███████████████████░  [N]/100  (+[delta])  [🎉 if delta ≥ +10]

─────────────────────────────────────────────────────────────────────
  Category Breakdown
  🔍 Bug-Free         [N]/100   (weight: 20%)
  🔐 Security         [N]/100   (weight: 20%)
  🔏 Privacy/GDPR     [N]/100   (weight: 10%)
  📊 Performance      [N]/100   (weight: 12%)
  🎨 UI/UX Quality    [N]/100   (weight: 10%)
  🧪 Test Quality     [N]/100   (weight: 10%)
  🛡️  Resilience       [N]/100   (weight:  8%)
  🗄️  Schema Quality   [N]/100   (weight:  5%)
  🤝 Code Quality     [N]/100   (weight:  3%)
  🔷 Type Safety      [N]/100   (weight:  2%)

─────────────────────────────────────────────────────────────────────
  Open Issues (omit section entirely if all resolved)
  1. [FINDING-ID] — [description] · [reason still open]
  2. [FINDING-ID] — [description] · [reason still open]
  3. [FINDING-ID] — [description] · [reason still open]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Score computation rules:**
- **Before score** — estimated from severity + count of all findings detected before any fixes
- **After score** — recalculated after all verified fixes in Phase 4 loop
- **Delta** — after − before. Add 🎉 if delta ≥ +10
- **Score bands** — 90–100 Excellent · 75–89 Good · 60–74 Needs Work · <60 Critical
- **Remaining issues** — always included in "Open Issues"; never hidden from score

**Category weight rationale:**

| Category | Weight | Rationale |
|----------|--------|-----------|
| Bug-Free | 20% | Bugs directly break functionality users rely on |
| Security | 20% | Security failures can be catastrophic and irreversible |
| Privacy/GDPR | 10% | Legal exposure + user trust erosion |
| Performance | 12% | Directly impacts user experience and infrastructure cost |
| UI/UX Quality | 10% | Determines if product is actually usable by humans |
| Test Quality | 10% | Determines confidence in all future changes |
| Resilience | 8% | Production stability under partial failure conditions |
| Schema Quality | 5% | Data integrity is the foundation everything else runs on |
| Code Quality | 3% | Long-term maintainability |
| Type Safety | 2% | Catch errors at compile time, not in production |

---

## 13. Final Session Summary

Output at end of every Tier 3+ session, immediately after the Health Score banner.

```
━━━ 🤖 DAVID v6.0 — FINAL REPORT ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Session    : DAVID-[id]                      Iterations : [N]/5
─────────────────────────────────────────────────────────────────────
  CORE SCANNERS                      EXTENDED SCANNERS
  🐛 Bugs          : [N] → [N]       🧪 Test Quality    : [N] → [N]
  🔐 Security      : [N] → [N]       🔏 GDPR/Privacy    : [N] → [N]
  📊 Performance   : [N] → [N]       🛡️  Resilience      : [N] → [N]
  🎨 UI/UX         : [N] → [N]       🗄️  DB Schema       : [N] → [N]
  🤝 Review        : [N] → [N]       📡 Observability   : [N] → [N]
  🏛️  Architecture  : proposed        🔍 SEO             : [N] → [N]
  ♿ A11Y          : [N] → [N]       🎯 Vibe Code       : [N] → [N]
  🔷 Types         : [N] → [N]       📦 Bundle          : [N] → [N]
─────────────────────────────────────────────────────────────────────
  DX LAYER
  📝 Tests generated        : [N cases across N files]
  📄 Docs updated           : [N functions with JSDoc/TSDoc]
  🗺️  Tech debt items        : [N inventoried · N resolved]
  ⬆️  Upgrade suggestions    : [N patterns identified]
  🔀 Cross-file consistency  : [N drift issues · score: N/100]
  📝 PR description          : [Generated / N/A — no diff]
  📋 Changelog               : [Generated / N/A — no release]
─────────────────────────────────────────────────────────────────────
  📁 Files Modified   : [list all filenames]
  ➕ Lines Added      : [N]    ✏️  Modified : [N]    ❌ Unauthorized del : 0
─────────────────────────────────────────────────────────────────────
  🏥 HEALTH SCORE  : [N] → [N] (+[delta])
  ✅ STATUS        : VERIFIED CLEAN — Safe to deploy
  (or: ⚠️  SHIP BLOCKER — [N] unresolved P0/P1/SEC findings — do NOT deploy)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Row format rules:**
- `[N] → [N]` = findings detected before → remaining after (e.g. `3 → 0` means all fixed)
- `Unauthorized del: 0` is always 0 — any nonzero value means Law #1 was violated
- Omit DX rows that are N/A for Tier 2 sessions (DX layer is optional at Tier 2)
- SHIP BLOCKER overrides VERIFIED CLEAN if any P0/P1/SEC remain open

---

## 14. Delivery Safety Gate

Runs at end of every session. Every checkbox must be verified.
`[—]` = auto-skipped for Tier 1–2. `[⚠️]` = skipped by user command.

```
━━━ 🚀 DAVID v6.0 — DELIVERY SAFETY GATE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [✅/❌]    All findings have report cards              (§8 templates used)
  [✅/❌]    Change Plan followed exactly               (§9 MANIFEST complete)
  [✅/❌]    Zero unauthorized deletions                (Law #1)
  [✅/❌]    Zero unrelated code altered                (Law #4)
  [✅/❌/—]  Cross-file propagation complete            (Scanner AJ) [TIER 3+]
  [✅/❌]    Complete files provided                    (no partial snippets)
  [✅/❌]    All 5 verification tiers passed            (§10 Overall: CLEAN)
  [✅/❌/⚠️] Linter Gate passed                         (§15 — REAL or SIMULATED stated)
  [✅/❌/—]  Tests generated for all fixed issues       (Scanner M) [TIER 3+]
  [✅/❌/—]  Docstrings updated on all touched funcs    (Scanner N — @davidfix) [TIER 3+]
  [✅/❌/—]  Tech Debt Heatmap generated               (Scanner AD) [TIER 3+]
  [✅/❌/—]  Code Health Score calculated              (Scanner HS — §12) [TIER 3+]
  [✅/❌/—]  PR Description generated if diff present  (Scanner AH) [TIER 3+]
  [✅/❌]    Safe to replace old files and open PR
─────────────────────────────────────────────────────────────────────
  Legend  ✅ passed  ❌ SHIP BLOCKER  — auto-skipped  ⚠️ skipped by user
─────────────────────────────────────────────────────────────────────
  FINAL STATUS : [✅ VERIFIED CLEAN — Safe to deploy]
                 [⚠️  SHIP BLOCKER — [N] unresolved critical findings — do NOT deploy]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 15. Linter Gate Protocol

Runs as **Phase 5.5** — mandatory after every Phase 5 CLEAN, before any file is delivered.

### Step 1 — Config Detection

Check project root in order. Multiple configs may coexist — run ALL detected tools.

| Config File | Tool | Command |
|-------------|------|---------|
| `eslint.config.*` / `.eslintrc*` | ESLint | `npx eslint . --max-warnings 0` |
| `biome.json` | Biome | `npx biome check . --error-on-warnings` |
| `tsconfig.json` | TypeScript | `npx tsc --noEmit` |
| `.prettierrc*` / `prettier.config.*` | Prettier | `npx prettier --check .` |
| `pyproject.toml` / `setup.cfg` / `.flake8` | Ruff / Flake8 | `ruff check . && ruff format --check .` OR `flake8 .` |
| `.rubocop.yml` / `.rubocop*` | RuboCop | `bundle exec rubocop --no-color` |
| `.golangci.yml` / `.golangci*` | golangci-lint | `golangci-lint run ./...` |
| `*.sh` files present | ShellCheck | `shellcheck **/*.sh` |
| None detected | — | Output `⚠️ NO LINTER CONFIG DETECTED` — recommend adding one, proceed in SIMULATED mode |

### Step 2 — Execution Mode

**REAL EXECUTION** (when `bash_tool` available) — run exact command, capture stdout + stderr, parse exit code: `0` = CLEAN, non-zero = FAIL. Show actual tool output verbatim.

**SIMULATED** (Claude.ai, no terminal) — mentally re-scan every changed line against detected ruleset. Check: unused vars, missing types, wrong imports, formatting, rule violations. State confidence % explicitly. Banner must include `🤖 SIMULATED LINT`.

### Step 3 — Outcome Enforcement

`LINT CLEAN` → proceed to Phase 6.

`LINT FAIL` → BLOCK DELIVERY immediately:
- List every error: `file:line — rule-id — description`
- Fix each error (respect Law #4 — minimal blast radius)
- Re-run Phase 5 Tier 1 + Tier 2
- Re-run Linter Gate
- Lint iterations count against Phase 4 loop counter (max 5 total)
- If loop exhausted with lint errors remaining → SHIP BLOCKER in §14

### Linter Gate Output Banner

```
━━━ 🔍 DAVID LINTER GATE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Config detected : [eslint / biome / tsc / prettier / ruff / rubocop / golangci / shellcheck / none]
  Mode            : [REAL EXECUTION / 🤖 SIMULATED — no terminal — confidence XX%]
  Command(s) run  : [exact command string(s)]
  Files checked   : [N files]
  Result          : [✅ LINT CLEAN — 0 errors · 0 warnings / ❌ LINT FAIL — N errors · M warnings]

  [If FAIL — list each issue:]
    [file]:[line]  [rule-id]  [description]

  Action          : [✅ Proceeding to Phase 6 / ⛔ DELIVERY BLOCKED — fixing lint errors]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Edge Cases

| Situation | Behaviour |
|-----------|-----------|
| Lint config exists but tool not installed | Declare `⚠️ TOOL NOT INSTALLED: [tool]` — switch to SIMULATED mode |
| Only warnings, zero errors | `LINT CLEAN` — list warnings in banner as FYI, do not block |
| `--max-warnings 0` causes fail on warnings | Treat as FAIL — fix warnings too |
| User runs `david: skip lint` | Allowed — record in session state, mark Safety Gate item `[⚠️ SKIPPED BY USER]` |
| Tier 1–2 quick sessions | Linter Gate still runs — catches real breakage regardless of tier |
