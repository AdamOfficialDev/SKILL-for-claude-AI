# DAVID v6.0 — Session Protocols (DEPRECATED STUB)

> ⚠️ This file has been split into three focused files for context efficiency.
> **Do NOT load this file.** Load the correct file below instead.

## Where to go

| Need | Load this file |
|------|---------------|
| Session lifecycle, state tracker, continuation, memory rules, file request protocol, fingerprint | `references/session/core.md` |
| All `david:` override commands, scope, finding management, export, format, mode, history | `references/session/commands.md` |
| Finding report cards, change plan, verification tiers, health score, safety gate, linter gate | `references/session/templates.md` |

---

If you are reading this file because a reference pointed here, that reference is stale.
The correct file for the section you need is listed in the table above.
