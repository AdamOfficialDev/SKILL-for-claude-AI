# DAVID — Code Quality Reference (Router)

Scanners A, C, D, UA, E, RF, P, Q, R, S, Z, AD, W, V master index. 8 files covering bug patterns, performance, code review, architecture, type safety, tech debt, state management, and bundle optimization.

## Which file to load?

| When auditing... | Load |
|------------------|------|
| Runtime bugs, logic errors, async issues, resource leaks | `references/code/bug-patterns.md` |
| Big-O issues, N+1 queries, memory leaks, sync blocking, DB query hints | `references/code/performance.md` |
| Code smells, naming violations, missing error handling, upgrade advisor | `references/code/code-review.md` |
| SOLID violations, coupling/cohesion, layer violations, refactoring plan | `references/code/architecture.md` |
| TypeScript `any` epidemic, missing annotations, unsafe assertions | `references/code/type-safety.md` |
| Dead code, error coverage, cyclomatic complexity, feature flags, tech debt heatmap | `references/code/tech-debt.md` |
| Redux anti-patterns, Zustand pitfalls, Context re-renders, server state | `references/code/state-management.md` |
| Barrel file patterns, missing code splitting, heavy dependency alternatives | `references/code/bundle.md` |
| **Full code quality audit** | **All 8 files** |

## Sub-file Summary

| File | Scanners | Lines | Use Case |
|------|----------|-------|----------|
| `code/bug-patterns.md` | A — BUG | ~128 | Any code + error / bug report |
| `code/performance.md` | C — PERF | ~462 | "slow" / DB code / loops |
| `code/code-review.md` | D — REVIEW + UA — UPGRADE | ~464 | "review" / any code / legacy patterns |
| `code/architecture.md` | E — ARCH + RF — REFACTOR | ~416 | "architecture" / multi-file / CC > 15 |
| `code/type-safety.md` | P — TYPES | ~246 | TypeScript files |
| `code/tech-debt.md` | Q + R + S + Z + AD | ~277 | "cleanup" / "unused" / any code |
| `code/state-management.md` | W — STATE | ~220 | Redux / Zustand / Context |
| `code/bundle.md` | V — BUNDLE | ~182 | Webpack / Vite / Next.js |

## Loading Rules

```
error / bug report          → code/bug-patterns.md (always check)
"slow" / DB / loops         → code/performance.md
"review" / any code         → code/code-review.md
"architecture" / multi-file → code/architecture.md
TypeScript files            → code/type-safety.md
"cleanup" / TODO/FIXME      → code/tech-debt.md
Redux/Zustand/Context       → code/state-management.md
Webpack/Vite/Next.js        → code/bundle.md
RF — REFACTOR (CC > 15)     → code/architecture.md (RF section)
UA — UPGRADE (legacy)       → code/code-review.md (UA section)
```

> `code/architecture.md` contains both E — ARCH and RF — REFACTOR. RF activates automatically when CC > 15, or on "refactor" request. RF always **PROPOSE ONLY, never auto-apply**.
