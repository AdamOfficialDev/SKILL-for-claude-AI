# MODULE 01 — RISK MANAGEMENT ENGINE

## 1.1 LOT SIZE CALCULATOR (FULL PRECISION)

### Standard Formula
```
Risk Amount ($) = Account Balance × (Risk% / 100)
Pip Value per Lot = depends on pair type (see table below)
Lot Size = Risk Amount / (SL in Pips × Pip Value per Lot)
```

### Pip Value Table
| Pair Type | Example | Pip Value (Standard Lot) | Notes |
|---|---|---|---|
| XXX/USD | EUR/USD, GBP/USD | $10.00 | Straightforward |
| USD/XXX | USD/JPY, USD/CAD | $10 / current rate | Divide by rate |
| JPY pairs | EUR/JPY, GBP/JPY | $10 / USDJPY rate | JPY pip = 0.01 |
| Cross pairs | EUR/GBP | $10 × (GBP/USD rate) | Convert via quote |
| Gold (XAU/USD) | — | $1.00 per pip ($0.01 move) | Pip = $0.10 |
| Oil (WTI/USD) | — | $10.00 per pip | 1 lot = 1000 barrels |

### Kalkulasi Template Lengkap
```
═══════════════════════════════════════
        LOT SIZE CALCULATION
═══════════════════════════════════════
Account Balance    : $[X]
Risk Percentage    : [X]%
Risk in USD        : $[X × risk%]
─────────────────────────────────────
Pair               : [PAIR]
Current Price      : [X]
Pip Size           : [0.0001 or 0.01]
Stop Loss          : [X] pips
Pip Value/Std Lot  : $[X]
─────────────────────────────────────
RESULT:
Standard Lots      : [X] lots
Mini Lots          : [X] mini lots
Micro Lots         : [X] micro lots
─────────────────────────────────────
Actual $ at Risk   : $[X]
Margin Required    : $[X] (1:[leverage])
Leverage Used      : [X:1 effective]
═══════════════════════════════════════
```

---

## 1.2 RISK/REWARD FRAMEWORK

### R:R Quick Reference
| R:R | Min Win Rate to Break Even | Verdict |
|---|---|---|
| 1:1 | 50.0% | Marginal — not recommended |
| 1:1.5 | 40.0% | Acceptable minimum |
| 1:2 | 33.3% | Good — standard |
| 1:3 | 25.0% | Excellent |
| 1:4 | 20.0% | Elite level |
| 1:5 | 16.7% | Sniper trader |

### Adjusted R:R (After Spread & Commission)
```
Spread Cost = spread_pips / SL_pips  (reduces effective R:R)
Commission Impact = (commission_per_lot × lots) / risk_amount

Adjusted R:R = (TP_pips - spread) / (SL_pips + spread)

Example: 20 pip SL, 40 pip TP, 2 pip spread
Raw R:R = 2.0
Adjusted R:R = (40-2)/(20+2) = 38/22 = 1.73
```

---

## 1.3 PORTFOLIO HEAT SYSTEM

```
HEAT LEVEL ASSESSMENT:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🟢 COOL    (0–3%)   : Sangat aman, bisa tambah trades
🟡 WARM    (3–6%)   : Normal, monitor ketat
🟠 HOT     (6–10%)  : Hati-hati, kurangi size baru
🔴 BURNING (>10%)   : STOP open trades baru
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CORRELATED HEAT MULTIPLIER:
Jika trading 2 pair korelasi tinggi (>0.8):
Effective Heat = heat1 + heat2 × correlation_factor
Example: EUR/USD 2% + GBP/USD 2% (corr 0.85)
Effective Heat = 2 + (2 × 0.85) = 3.7% bukan 4%
(Karena tidak fully independent)
```

---

## 1.4 POSITION SIZING METHODS

### Method 1: Fixed Percentage (Recommended Beginners)
```
Risk = 1–2% per trade
Simple, consistent, easy to track
```

### Method 2: ATR-Based Volatility Sizing
```
Normal_Risk_$ = Balance × risk%
Volatility_Ratio = Current_ATR / Average_ATR_20periods
Adjusted_Lot = Normal_Lot / Volatility_Ratio

→ High volatility = smaller lot (automatic protection)
→ Low volatility = larger lot (more opportunity)
```

### Method 3: Kelly Criterion (Advanced)
```
Kelly% = W - [(1-W) / R]
Where: W = win rate decimal, R = avg win/avg loss ratio

CONSERVATIVE USAGE:
- Full Kelly: theoretical max, too volatile in practice
- Half Kelly (W/2): recommended for most traders
- Quarter Kelly (W/4): most conservative, smooth equity curve

Example: 55% win rate, 1.5 R:R
Kelly% = 0.55 - (0.45/1.5) = 0.55 - 0.30 = 25%
Half Kelly = 12.5% (still aggressive for most)
Quarter Kelly = 6.25% (reasonable for funded accounts)
```

### Method 4: Fixed Dollar Risk
```
Always risk same $ amount regardless of account growth
→ Protects profits but limits compounding
→ Good for: strict prop firm rules
```

---

## 1.5 DRAWDOWN RECOVERY CALCULATOR

```
DRAWDOWN → REQUIRED GAIN TO RECOVER:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Loss     | Recovery Needed
5%       | 5.26%
10%      | 11.11%
20%      | 25.00%   ← Significant
30%      | 42.86%   ← Serious
40%      | 66.67%   ← Critical
50%      | 100.00%  ← Must double
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Formula: Recovery% = (Loss% / (100 - Loss%)) × 100

LESSON: Protect capital at all costs.
After 5 consecutive 2% losses → 9.4% DD → needs 10.4% to recover
```

---

## 1.6 COMPOUND GROWTH CALCULATOR

```
Formula: FV = PV × (1 + r)^n
FV = Future Value
PV = Present Value (starting balance)
r  = return per period (as decimal)
n  = number of periods

MONTHLY 5% RETURN PROJECTIONS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Month 1:  $1,050     | Month 6:  $1,340
Month 12: $1,796     | Month 24: $3,225
Month 36: $5,792     | ← $10k starts → $57,920

REALITY CHECK:
- 5% monthly = 60% annual → exceptional
- Realistic target for consistent trader: 3–5% monthly
- Prop firm passer standard: 8–10% monthly
```

---

## 1.7 SWAP/OVERNIGHT COST ANALYSIS

```
Daily Swap Cost = (Lot Size × Contract Size × Interest Rate Differential) / 365

Long swap positive: when you buy higher-rate currency
Long swap negative: when you buy lower-rate currency

CARRY TRADE CALCULATION:
Net Annual Carry = (Rate_Buy - Rate_Sell) × Notional Value

Example: AUD/JPY long
AUD rate: 4.35%, JPY rate: 0.10%
Carry = (4.35% - 0.10%) × $100,000 = $4,250/year ($11.64/day per lot)

SWAP CHECK CHECKLIST:
□ Check swap rates in broker platform (3-day Wednesday swap!)
□ Account for swap in overall trade profitability
□ For long-term trades: swap can significantly erode profits
□ For carry trades: swap IS the profit strategy
```
