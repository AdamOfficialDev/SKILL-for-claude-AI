# MODULE 08 — TRADING PSYCHOLOGY & MINDSET

## 8.1 TRADER DEVELOPMENT STAGES

```
STAGE 1 — UNCONSCIOUS INCOMPETENCE ("Beginner's Confidence")
→ Just started, feels exciting
→ Doesn't know what they don't know
→ Overconfident after a few wins
→ Usually destroys account in 3-6 months

STAGE 2 — CONSCIOUS INCOMPETENCE ("The Valley of Despair")
→ Realizes how much they don't know
→ Studies indicators, strategies, analysis
→ Still losing, but learning why
→ Most quit here — THIS IS WHERE MOST FAIL
→ KEY: Push through this stage

STAGE 3 — CONSCIOUS COMPETENCE ("Mechanical Trading")
→ Has rules and follows them
→ Profitable but requires concentration
→ Can't scale yet — psychology still limiting
→ Building discipline muscles

STAGE 4 — UNCONSCIOUS COMPETENCE ("The Zone")
→ Rules are automatic, no effort
→ Consistently profitable
→ Reads market intuitively
→ Can mentor others
→ Only ~5-10% of traders reach this level

WHERE ARE YOU? Honest self-assessment = faster growth
```

---

## 8.2 COGNITIVE BIASES IN TRADING

### The Six Deadly Biases
```
1. CONFIRMATION BIAS
→ Symptom: Only seeing evidence that supports your trade
→ Fix: Write down the bearish case BEFORE every trade
→ Rule: If you can't articulate a valid opposing case → don't trade

2. LOSS AVERSION
→ Symptom: Holding losses too long, cutting profits too short
→ Psychology: Pain of loss = 2× joy of equivalent gain
→ Fix: Pre-define exit levels, use OCO orders, honor your plan

3. FOMO (Fear Of Missing Out)
→ Symptom: Chasing price after missing entry
→ Fix: "Missed trades don't exist" mantra
→ Rule: If price is more than 50% of SL distance from your entry → SKIP
→ Remember: Markets produce opportunities EVERY day

4. REVENGE TRADING
→ Symptom: Larger size after loss to "get it back"
→ Fix: After any loss → 30-minute break minimum
→ Rule: Never increase position size after a loss
→ 3 consecutive losses = stop for the day, review tomorrow

5. OVERCONFIDENCE
→ Symptom: Increasing size after win streak
→ Fix: Size is ALWAYS based on account balance and rules, never emotions
→ Rule: Maximum 2 winning sessions in a row before size review

6. ANCHORING
→ Symptom: "It was at 1.25, it'll go back there" thinking
→ Fix: Price doesn't remember where it came from
→ Rule: Analyze current structure only, not where you wish price was
```

---

## 8.3 PRE-TRADE CHECKLIST (COMPLETE)

```
╔════════════════════════════════════════════════════════╗
║              PRE-TRADE CHECKLIST v2.0                  ║
╠════════════════════════════════════════════════════════╣
║ MARKET ANALYSIS                                        ║
║ □ HTF trend identified (Daily or 4H)                   ║
║ □ Major S/R levels drawn on all TFs                    ║
║ □ Market structure confirmed (HH+HL or LH+LL)          ║
║ □ HTF bias: Bullish / Bearish / Neutral                 ║
║ □ Economic calendar checked — no news in 1H            ║
║ □ Correlated pairs checked (not fighting the trend)     ║
╠════════════════════════════════════════════════════════╣
║ SETUP QUALITY                                          ║
║ □ Entry criteria clearly met (not "close enough")      ║
║ □ 3+ confluence factors present                        ║
║ □ SL is logical (structure-based, not arbitrary)       ║
║ □ R:R ratio minimum 1:1.5                              ║
║ □ Lot size calculated correctly                        ║
║ □ Portfolio heat after this trade: ___% (must be <10%) ║
╠════════════════════════════════════════════════════════╣
║ MENTAL STATE                                           ║
║ □ Did I sleep well? (Yes/No)                           ║
║ □ Last trade result: Win/Loss/BE → feeling neutral?    ║
║ □ NOT in revenge mode from previous loss               ║
║ □ NOT FOMO-chasing a missed move                       ║
║ □ NOT increasing size to "make back" losses            ║
║ □ Trading plan written down in advance                 ║
║ □ "I'm okay with this trade being a full loss" — YES   ║
╠════════════════════════════════════════════════════════╣
║ TRADE LOG READY                                        ║
║ □ Trade ticket filled before entry                     ║
║ □ Screenshot of setup taken                            ║
║ □ Exit plan clear (what will make me exit early?)      ║
╚════════════════════════════════════════════════════════╝

If ANY box is unchecked → DELAY or SKIP the trade
```

---

## 8.4 DISCIPLINE SYSTEMS

### Daily Routine for Consistent Traders
```
PRE-SESSION (30-60 min before):
□ Review economic calendar
□ Mark key S/R levels on working pairs
□ Check HTF trend/bias
□ Write "today's game plan" (which setups, which pairs)
□ Set profit target and maximum daily loss limit

DURING SESSION:
□ Only look at pre-identified pairs and setups
□ No news-surfing or social media while trading
□ Record every trade in journal immediately
□ Check portfolio heat after each entry

POST-SESSION:
□ Review all trades (won or lost)
□ Grade execution quality (not just outcome!)
□ Write 1 lesson from today
□ Calculate daily P&L
□ End session completely (close charts, mentally disconnect)
```

### Loss Management Protocol
```
TIERED RESPONSE SYSTEM:
1st Loss: Continue trading (normal)
2nd Loss: Reduce position size by 25%
3rd consecutive Loss: STOP for 30 minutes, review
4th consecutive Loss: STOP for the day

DAILY LOSS LIMIT:
→ Set personal maximum: e.g., -3% of account
→ When hit: CLOSE ALL TRADES, CLOSE PLATFORM, DONE for day
→ Non-negotiable

MONTHLY DRAWDOWN LIMIT:
→ Set at: -10% maximum (retail) | -5% (prop firm)
→ When hit: Reduce to half position sizes until recovered
→ Re-evaluate strategy after 15% monthly drawdown
```

---

# MODULE 09 — INTERMARKET & MACRO ANALYSIS

## 9.1 THE GLOBAL MACRO FRAMEWORK

### Risk-On vs Risk-Off Model
```
RISK-ON ENVIRONMENT (Buy risk assets):
→ Triggers: Strong GDP, falling unemployment, recovering markets
→ Winners: AUD, NZD, CAD, high-yield EM currencies
→ Losers: JPY, CHF, USD (sometimes)
→ Indicators: VIX < 15, S&P 500 rising, high yield spreads tight

RISK-OFF ENVIRONMENT (Buy safe havens):
→ Triggers: Recession fears, geopolitical crisis, market crash
→ Winners: JPY, CHF, USD, Gold
→ Losers: AUD, NZD, EM currencies, GBP
→ Indicators: VIX > 25, S&P 500 falling, gold rising, bonds rising

TRANSITION SIGNALS:
→ VIX crossing 20 = risk appetite shifting
→ Rapid JPY or CHF rally = risk-off emerging
→ AUD/JPY falling sharply = risk-off (most reliable barometer)
```

## 9.2 DXY (US DOLLAR INDEX) ANALYSIS

```
DXY COMPOSITION:
EUR: 57.6%    JPY: 13.6%    GBP: 11.9%
CAD: 9.1%     SEK: 4.2%     CHF: 3.6%

DXY is essentially short EUR/long everything else

DXY KEY LEVELS:
→ 100.00 = major psychological level
→ DXY at multi-year highs = pressure on EM, commodities
→ DXY at multi-year lows = commodity currencies and gold rally

TRADING DXY:
→ DXY breaks resistance → sell EUR/USD, GBP/USD, AUD/USD
→ DXY breaks support → buy EUR/USD, GBP/USD, AUD/USD
→ Use DXY as macro confirmation for USD pair entries
```

## 9.3 YIELD ANALYSIS FOR FOREX

```
KEY YIELD SPREADS:
US 10yr - German 10yr = EUR/USD directional bias
→ Spread widening (US yields rising more) = USD/EUR bullish → EUR/USD bearish
→ Spread narrowing = EUR/USD bullish

US 10yr - Japan 10yr = USD/JPY directional bias
→ Most direct correlation: rising US-JP spread = USD/JPY UP
→ BOJ yield curve control (YCC) = ceiling on JGB yields = always check BOJ policy

REAL YIELDS (Nominal Yield - Inflation):
→ Positive real yields = currency attractive
→ Negative real yields = currency unattractive, sell
→ Gold inversely correlated with US real yields

YIELD CURVE INVERSION (2yr > 10yr):
→ Historically predicts recession 12-18 months later
→ USD initially strengthens then weakens when recession hits
→ JPY and CHF benefit from risk-off in recession
```
