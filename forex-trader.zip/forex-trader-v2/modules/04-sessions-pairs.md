# MODULE 04 — MARKET SESSIONS & PAIR PROFILES

## 4.1 TRADING SESSIONS COMPLETE GUIDE

### Session Times & Characteristics
```
╔══════════════════════════════════════════════════════════════╗
║              FOREX MARKET SESSION CLOCK (UTC)                ║
╠══════════════════════════════════════════════════════════════╣
║ SYDNEY    22:00 – 07:00 UTC  │ Low volume, AUD/NZD focus     ║
║ TOKYO     00:00 – 09:00 UTC  │ JPY pairs, moderate vol       ║
║ LONDON    08:00 – 17:00 UTC  │ HIGHEST VOLUME (40% daily)    ║
║ NEW YORK  13:00 – 22:00 UTC  │ USD pairs, US news            ║
╠══════════════════════════════════════════════════════════════╣
║ OVERLAP: London+NY 13:00–17:00 UTC = PEAK VOLATILITY         ║
║ OVERLAP: Tokyo+London 07:00–09:00 UTC = Good for JPY         ║
╚══════════════════════════════════════════════════════════════╝

WIB (Jakarta UTC+7) CONVERSION:
Sydney Open:   05:00 WIB
Tokyo Open:    07:00 WIB
London Open:   15:00 WIB ← Key session for most traders
NY Open:       20:00 WIB
London-NY Overlap: 20:00 – 00:00 WIB ← PRIME TIME
NY Close:      05:00 WIB
```

### Best Pairs by Session
```
TOKYO SESSION (07:00-16:00 WIB):
Primary:   USD/JPY, EUR/JPY, GBP/JPY, AUD/JPY
Secondary: AUD/USD, NZD/USD, USD/SGD
Strategy:  Range-bound, look for Asia range breakout
Avoid:     EUR/USD, GBP/USD (often stuck in tight range)

LONDON SESSION (15:00-01:00 WIB):
Primary:   EUR/USD, GBP/USD, EUR/GBP, EUR/JPY, GBP/JPY
Secondary: USD/CHF, AUD/USD
Strategy:  Trend following, London breakout strategy
Best time: First 2 hours (15:00-17:00 WIB) for London breakout

NEW YORK SESSION (20:00-05:00 WIB):
Primary:   EUR/USD, GBP/USD, USD/CAD, USD/CHF
Secondary: All major pairs active
Best time: First 2 hours (20:00-22:00 WIB) = London-NY overlap peak
Overlap:   20:00-00:00 WIB = highest daily volume

OVERNIGHT/DEAD ZONE (01:00-07:00 WIB):
Low volume, erratic moves
Mostly avoid unless position trader
```

### London Breakout Strategy
```
SETUP:
1. Mark Asia session range (high and low from 00:00-07:00 UTC)
2. At London open (08:00 UTC / 15:00 WIB):
   → Wait for 15-30 min to assess initial direction
3. Entry: Break of Asia range high/low with strong momentum candle
4. SL: Opposite side of Asia range + 5 pip buffer
5. TP: 1.5x–2x the range size

FILTER:
→ Only trade in direction of D1 trend
→ No high-impact news within 1 hour
→ ATR > 80% of 20-period average (some volatility needed)
→ Volume spike on breakout candle (if volume available)

SUCCESS RATE NOTE: Works best Monday-Wednesday, avoid Thursday/Friday
```

---

## 4.2 CURRENCY PAIR PROFILES

### Major Pairs

**EUR/USD — The Most Traded Pair**
```
Average Daily Range: 80-120 pips (higher on news days)
Spread: 0.0-1.0 pip (ECN) | 1-2 pips (standard)
Best Sessions: London, NY overlap
Character: Trending pair, respects technical levels well
Key Drivers: ECB vs Fed policy, EU/US economic data, risk sentiment
Special Notes:
→ 22:00-00:00 UTC = manipulation hour (fake moves before London)
→ Strong Fibonacci respector
→ Correlated with gold (inverse USD)
Correlation: +0.85 GBP/USD, +0.80 AUD/USD, -0.95 USD/CHF
```

**GBP/USD — "The Cable"**
```
Average Daily Range: 100-150 pips (volatile!)
Spread: 1-3 pips typical
Best Sessions: London (especially first 2 hours)
Character: Volatile, fast moves, prone to spike reversals
Key Drivers: BOE policy, UK economic data, Brexit aftermath, USD sentiment
Special Notes:
→ Most volatile major pair — larger SL needed
→ BOE rate decisions cause extreme moves (200+ pips possible)
→ UK political news creates unpredictable spikes
→ Great for momentum/breakout strategies
Correlation: +0.85 EUR/USD
```

**USD/JPY — "The Ninja"**
```
Average Daily Range: 80-120 pips
Spread: 0-1 pip
Best Sessions: Tokyo, NY (sensitive to US yields and risk sentiment)
Character: Trend-following, risk-sentiment driven
Key Drivers: Fed vs BOJ policy, US Treasury yields, risk appetite
Special Notes:
→ MOST SENSITIVE to US 10-year Treasury yields (daily correlation)
→ Risk-off = JPY strengthens sharply (USD/JPY falls)
→ BOJ interventions: Japan often intervenes above 150.00
→ Ascending/descending wedges common pattern
→ Thin Tokyo session = range bound; NY = trending
```

**USD/CHF — "The Swissy"**
```
Average Daily Range: 60-80 pips
Spread: 1-2 pips
Character: Safe haven, inverse EUR/USD
Key Drivers: SNB policy, risk sentiment, EU developments
Special Notes:
→ Almost perfect -0.95 correlation with EUR/USD (trade one, you trade both)
→ CHF = safe haven like JPY but more controlled by SNB
→ SNB known for surprise interventions (Brexit 2015: 300+ pip spike)
→ Lower volatility = better for beginners
```

**AUD/USD — "The Aussie"**
```
Average Daily Range: 60-90 pips
Character: Commodity-linked, China-sensitive, risk currency
Key Drivers: RBA policy, Australian economic data, China PMI/GDP, iron ore, gold
Special Notes:
→ AUD and Gold (XAU): ~0.80 correlation
→ AUD and China: When China data disappoint → AUD falls
→ Iron ore price changes affect AUD
→ RBA less active = less BOJ-style surprises
→ Risk-on/off very sensitive pair
```

**USD/CAD — "The Loonie"**
```
Average Daily Range: 60-80 pips
Character: Oil-linked, strong correlation with crude prices
Key Drivers: BOC policy, oil prices, US/Canada economic data
Special Notes:
→ Oil price UP = USD/CAD DOWN (CAD strengthens)
→ Oil price DOWN = USD/CAD UP
→ Inverted direction from other USD pairs (quote = CAD)
→ Canadian employment report (Friday, same week as NFP) often moves pair
→ OPEC decisions = USD/CAD opportunity
```

**NZD/USD — "The Kiwi"**
```
Average Daily Range: 50-70 pips
Character: Risk currency, commodity-linked, smaller liquidity
Key Drivers: RBNZ policy, NZ dairy prices, China trade, risk appetite
Special Notes:
→ Lower liquidity = wider spreads, less reliable technical levels
→ RBNZ often first to hike/cut (forward-looking)
→ High correlation with AUD/USD (0.90+)
→ New Zealand dairy auction data moves pair
```

### Cross Pairs

**EUR/JPY — "The Euro-Yen"**
```
Average Daily Range: 100-140 pips
Character: Risk barometer, combines EUR and JPY dynamics
Best Sessions: London, NY
Notes: Rising = risk-on | Falling = risk-off
Strong trending characteristics
```

**GBP/JPY — "The Dragon"**
```
Average Daily Range: 150-200 pips
Character: MOST VOLATILE major cross — respect or avoid
Notes:
→ Amplifies both GBP and JPY moves
→ Wild swings — requires very tight risk management
→ Excellent for experienced traders, dangerous for beginners
→ London session: can see 100+ pip moves in minutes
```

**EUR/GBP — "The Cross"**
```
Average Daily Range: 40-60 pips
Character: Very range-bound, slower mover
Notes:
→ Low daily range — requires tight SL and TP
→ UK vs EU economic divergence theme
→ Good for patient, precision traders
→ Brexit-related news = major spikes
```

---

## 4.3 CURRENCY CORRELATION MATRIX

```
          EUR/USD  GBP/USD  USD/JPY  AUD/USD  USD/CAD  USD/CHF  NZD/USD
EUR/USD     1.00     0.85    -0.70     0.80    -0.75    -0.95     0.78
GBP/USD     0.85     1.00    -0.65     0.72    -0.68    -0.82     0.70
USD/JPY    -0.70    -0.65     1.00    -0.60     0.55     0.65    -0.58
AUD/USD     0.80     0.72    -0.60     1.00    -0.80    -0.76     0.90
USD/CAD    -0.75    -0.68     0.55    -0.80     1.00     0.70    -0.78
USD/CHF    -0.95    -0.82     0.65    -0.76     0.70     1.00    -0.74
NZD/USD     0.78     0.70    -0.58     0.90    -0.78    -0.74     1.00

Values approximate. Refresh from reliable source for current data.

INTERPRETATION:
>0.70: Strongly positive (move together)
>0.90: Very strongly positive (almost identical)
<-0.70: Strongly negative (move opposite)
-0.40 to 0.40: Low correlation (independent)

TRADING RULES:
1. Never hold same-direction trades on >0.85 correlated pairs (doubles risk)
2. Use negative correlation for hedging (imperfect but reduces exposure)
3. Divergence between correlated pairs = potential trade opportunity
```
