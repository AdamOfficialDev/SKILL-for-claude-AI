# MODULE 03 — FUNDAMENTAL ANALYSIS DEEP DIVE

## 3.1 ECONOMIC CALENDAR MASTERY

### Event Impact Classification
```
🔴 TIER 1 — MARKET MOVING (Avoid trading 15 min before/after)
─────────────────────────────────────────────────────────────
NFP (Non-Farm Payroll)     : 1st Friday of month | 200-300 pip USD move
FOMC Rate Decision         : 8x/year | 100-200 pip USD move
ECB Rate Decision          : 8x/year | 80-150 pip EUR move
BOE Rate Decision          : 8x/year | 60-120 pip GBP move
BOJ Rate Decision          : 8x/year | 100-200 pip JPY move
SNB Rate Decision          : 4x/year | Volatile CHF
CPI (US)                   : Monthly | 50-100 pip move
GDP (Advance)              : Quarterly | 50-80 pip move
Central Bank Press Conf    : Same day as rate decision

🟡 TIER 2 — SIGNIFICANT (Tighten SL if in trade)
─────────────────────────────────────────────────────────────
ADP Employment             : Wednesday before NFP
Retail Sales               : Monthly | 30-60 pip
ISM Manufacturing/Services : Monthly
PMI Flash                  : Monthly | 20-40 pip
Core PCE Price Index       : Monthly (Fed's preferred inflation measure)
Unemployment Rate          : Monthly | 30-50 pip
PPI                        : Monthly
Trade Balance              : Monthly
Jobless Claims             : Weekly (lower impact now)
Fed/ECB/BOE Member Speeches: Any time — watch for hawkish/dovish tone

🟢 TIER 3 — MODERATE (Be aware, adjust expectations)
─────────────────────────────────────────────────────────────
Building Permits
Consumer Confidence (Michigan, Conference Board)
Durable Goods Orders
Factory Orders
Current Account Balance
```

### Interpreting Data — Surprise Factor Framework
```
FORMULA: Surprise = Actual − Forecast

POSITIVE SURPRISE (Actual > Forecast) = Currency BULLISH
NEGATIVE SURPRISE (Actual < Forecast) = Currency BEARISH
IN-LINE = Minimal reaction (already priced in)

NUANCES:
1. REVISION MATTERS: Previous period revision can override current print
   Example: NFP actual = 200k (inline) BUT previous revised UP from 150k to 200k
   → Net positive surprise, USD likely rises

2. "BUY THE RUMOR, SELL THE NEWS":
   Strong data expected for weeks → currency already priced in
   When data confirms → "sell on good news" trap
   → Watch positioning and market expectations, not just data

3. MULTI-DATA CONTEXT:
   Strong NFP but rising unemployment rate = mixed signal
   Strong retail sales but inflation falling = USD neutral to negative
   → Consider the FULL picture, not single data points

4. DELTA FROM TREND:
   If GDP has been growing 3% for 5 quarters and prints 2.8%
   → MISS even though 2.8% is good in absolute terms
```

---

## 3.2 CENTRAL BANK ANALYSIS

### Hawkish vs Dovish Language Monitor
```
🦅 HAWKISH SIGNALS (Currency Bullish):
Language: "robust", "persistent", "above target", "elevated", "overheating"
Actions: Rate hike | QE tapering | Balance sheet reduction
Forecasts: GDP upgrade | Inflation upgrade | Employment upgrade
Forward guidance: "Further tightening may be appropriate"

🕊️ DOVISH SIGNALS (Currency Bearish):
Language: "uncertainty", "accommodative", "below target", "gradual"
Actions: Rate cut | QE expansion | Yield curve control
Forecasts: GDP downgrade | Inflation downgrade
Forward guidance: "Patient approach warranted", "data dependent"

NEUTRAL: "Data dependent" without directional lean
```

### Fed (FOMC) Deep Analysis
```
FOMC MEETING COMPONENTS:
1. Rate Decision (most market-moving)
2. Statement (hawkish/dovish language shift)
3. Press Conference (Chair's tone = often more important than statement)
4. Dot Plot (quarterly — shows member rate projections)
5. Summary of Economic Projections (quarterly)

DOT PLOT READING:
→ Dots = individual FOMC member rate projections
→ Median dot = market consensus expectation
→ Shift up = more hawkish → USD bullish
→ Shift down = more dovish → USD bearish
→ 2024 dots shifted lower → USD weakened significantly

TRADING THE FOMC:
→ 15 min before: Reduce/close positions
→ Statement release: Wait for initial spike
→ Initial spike often reverses (first direction is "knee-jerk")
→ True direction: Usually established 15-30 min after statement
→ Press Conference starts 30 min after → second volatility event
```

### Interest Rate Differential Trading
```
CONCEPT: Higher rate currency attracts capital inflow → appreciation
LOW RATE CURRENCIES (usually sell): JPY, CHF, EUR (historically)
HIGH RATE CURRENCIES (usually buy): USD, AUD, NZD, CAD (varies)

RATE DIFFERENTIAL TABLE (update as rates change):
Pair: Look up current rates via web search
Calculate: Long rate - Short rate = Net carry

CARRY TRADE FRAMEWORK:
→ Buy high-rate currency, sell low-rate currency
→ Profit from: Daily swap + potential capital appreciation
→ Risk: Reversal of capital flows (global risk-off = carry unwind)
→ AUD/JPY and NZD/JPY = classic carry trade pairs

CARRY TRADE RISK SIGNALS (exit carry):
□ VIX spikes above 25 (risk-off environment)
□ Risk assets selling off broadly
□ Central bank pivots direction
□ Global recession fears emerging
```

---

## 3.3 COT (COMMITMENT OF TRADERS) REPORT

### Understanding COT Data
```
RELEASED: Every Friday, data from Tuesday
SOURCE: CFTC (Commodity Futures Trading Commission)
DATA: Net positions of different trader categories

CATEGORIES:
1. Commercial Hedgers: "Smart money" — actual businesses hedging exposure
   → When MOST short = they hedge production (not directional trading)
   → Actually contrarian indicator for futures
   
2. Non-Commercial (Large Speculators/Hedge Funds): 
   → MOST USEFUL for forex direction
   → Follow their net positioning changes
   → Extreme positioning = potential reversal

3. Non-Reportable (Small Speculators/Retail):
   → Contrarian indicator
   → When heavily long = often near top
   → When heavily short = often near bottom

COT SIGNAL:
Large Spec NET LONG increasing + price rising = BULLISH CONFIRMATION
Large Spec NET LONG at extreme + price stalling = REVERSAL ALERT
Large Spec NET SHORT increasing + price falling = BEARISH CONFIRMATION
Large Spec flipping from net short to net long = EARLY TREND CHANGE
```

### COT Extreme Reading
```
No absolute level for "extreme" — compare to historical range

METHOD:
1. Calculate 52-week high/low of net positions
2. Current position as % of range = COT Index
3. COT Index > 90% = Extreme Long (reversal caution)
4. COT Index < 10% = Extreme Short (reversal caution)

COMBINE WITH: Price action at key S/R for highest probability
```

---

## 3.4 INTERMARKET RELATIONSHIPS

### Key Correlations
```
DXY (US Dollar Index):
DXY UP → EUR/USD, GBP/USD, AUD/USD, NZD/USD, XAU/USD DOWN
DXY DOWN → Same pairs UP
→ DXY is the meta-indicator for all USD pairs

GOLD (XAU/USD):
→ Positive correlation with AUD/USD (~0.7-0.8)
→ Negative correlation with USD (inverse DXY)
→ Safe haven: rises with VIX, geopolitical risk
→ Real yields (10yr TIPS): Rising real yields = Gold bearish

OIL (WTI/Brent):
→ Positive correlation with CAD (Canada = oil exporter)
→ USD/CAD NEGATIVE correlation with oil
→ Also affects NOK, MXN, RUB
→ OPEC decisions move oil = trade USD/CAD opportunity

US 10-YEAR TREASURY YIELD:
→ Rising yields = USD bullish (capital attracted to US)
→ Yield curve inversion (2yr > 10yr) = recession signal
→ USD/JPY especially sensitive to yield differentials

VIX (Fear Index):
→ VIX > 20: Risk-off, sell risk currencies (AUD, NZD), buy JPY, CHF, USD
→ VIX < 15: Risk-on, buy risk currencies, sell JPY, CHF
→ VIX spike = carry trade unwind (JPY and CHF rally sharply)

EQUITIES (S&P 500):
→ Risk-on: S&P rallies, AUD/JPY, NZD/JPY, risk pairs rally
→ Risk-off: S&P falls, JPY/CHF rally
→ EUR/USD weak positive correlation (global risk appetite)
```

---

## 3.5 SEASONAL TENDENCIES

### Calendar-Based Patterns
```
JANUARY EFFECT: 
→ New year, new allocations
→ USD often weak in January (repatriation flows reversed)
→ Risk assets often start well

Q4 (October-December):
→ USD often strengthens (year-end repatriation)
→ December: Holiday low liquidity = erratic moves

MONTH-END / QUARTER-END:
→ Large institutional rebalancing
→ Can create sharp reversals last 2-3 days of month
→ EUR/USD and GBP/USD most affected

FRIDAY AFTERNOON (London/NY close):
→ Traders close positions → risk reduction
→ Trending moves often stall or reverse
→ Lower volume = gaps can form

SUMMER (June-August):
→ Lower liquidity (European traders on vacation)
→ USD pairs can be choppy, erratic
→ August especially — avoid overtrading
```
