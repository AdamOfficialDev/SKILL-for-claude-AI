# MODULE 02 — TECHNICAL ANALYSIS MASTERY

## 2.1 MARKET STRUCTURE (FOUNDATION)

```
UPTREND: Higher Highs (HH) + Higher Lows (HL)
DOWNTREND: Lower Highs (LH) + Lower Lows (LL)
RANGING: Equal Highs + Equal Lows (messy HH/LL)

KEY CONCEPTS:
Break of Structure (BOS):
→ In uptrend: price breaks ABOVE previous HH = continuation
→ In downtrend: price breaks BELOW previous LL = continuation

Change of Character (CHoCH):
→ First sign of trend reversal
→ Uptrend: price breaks BELOW previous HL = CHoCH
→ Downtrend: price breaks ABOVE previous LH = CHoCH

Swing High / Swing Low:
→ Swing High: candle high > both left and right neighbors
→ Swing Low: candle low < both left and right neighbors
→ Use for: S/R levels, SL placement, structure mapping
```

---

## 2.2 CANDLESTICK PATTERNS — COMPLETE REFERENCE

### Single Candle Patterns
| Pattern | Description | Signal | Reliability |
|---|---|---|---|
| Marubozu Bullish | Full body, no/tiny wicks | Strong bullish momentum | ★★★★ |
| Marubozu Bearish | Full body, no/tiny wicks | Strong bearish momentum | ★★★★ |
| Doji | Open ≈ Close, both wicks | Indecision — wait confirm | ★★ |
| Gravestone Doji | Long upper wick, close=low | Bearish reversal at top | ★★★ |
| Dragonfly Doji | Long lower wick, close=high | Bullish reversal at bottom | ★★★ |
| Hammer | Lower wick 2x+ body, at bottom | Bullish reversal | ★★★★ |
| Hanging Man | Lower wick 2x+ body, at TOP | Bearish reversal | ★★★ |
| Shooting Star | Upper wick 2x+ body, at top | Bearish reversal | ★★★★ |
| Inverted Hammer | Upper wick 2x+ body, at bottom | Bullish reversal | ★★★ |
| Spinning Top | Small body, equal wicks | Indecision | ★★ |

### Two Candle Patterns
| Pattern | Description | Signal |
|---|---|---|
| Bullish Engulfing | Green body fully engulfs previous red | Strong bullish reversal ★★★★★ |
| Bearish Engulfing | Red body fully engulfs previous green | Strong bearish reversal ★★★★★ |
| Tweezer Bottom | Two candles share same low | Bullish reversal ★★★ |
| Tweezer Top | Two candles share same high | Bearish reversal ★★★ |
| Bullish Harami | Small green inside large red | Potential bullish reversal ★★★ |
| Bearish Harami | Small red inside large green | Potential bearish reversal ★★★ |
| Piercing Line | Green close >50% into red body | Bullish reversal ★★★★ |
| Dark Cloud Cover | Red close >50% into green body | Bearish reversal ★★★★ |

### Three Candle Patterns
| Pattern | Description | Signal |
|---|---|---|
| Morning Star | Big Red + Small body + Big Green | Strong bullish reversal ★★★★★ |
| Evening Star | Big Green + Small body + Big Red | Strong bearish reversal ★★★★★ |
| Morning Doji Star | Big Red + Doji + Big Green | Very strong bullish reversal |
| Three White Soldiers | 3 progressive green candles | Bullish continuation ★★★★ |
| Three Black Crows | 3 progressive red candles | Bearish continuation ★★★★ |
| Three Inside Up | Harami + confirm green | Bullish reversal ★★★★ |
| Three Inside Down | Harami + confirm red | Bearish reversal ★★★★ |

**CONFIRMATION RULES:**
- Always wait for candle CLOSE before acting
- Volume should confirm (higher on signal candle)
- Context matters: pattern at key S/R >> same pattern in middle of range
- Higher TF patterns more reliable than lower TF

---

## 2.3 CHART PATTERNS — MEASURED MOVES

### Reversal Patterns
```
HEAD & SHOULDERS:
Pattern:    Left Shoulder → Head → Right Shoulder
Neckline:   Connect two troughs
Entry:      Break + retest of neckline
Target:     Measure head-to-neckline, project down from neckline
SL:         Above right shoulder
Volume:     Should decrease on right shoulder vs left

INVERTED H&S (bullish version): Mirror of above

DOUBLE TOP (M Pattern):
Two peaks at approximately same level
Volume lower on second peak
Entry: Break below neckline (valley between peaks)
Target: Height of pattern measured from neckline
SL: Above second peak
Confirmation: RSI divergence on second peak

DOUBLE BOTTOM (W Pattern): Mirror of double top (bullish)

TRIPLE TOP/BOTTOM: Same rules, 3 touches = stronger signal
```

### Continuation Patterns
```
FLAG:
Pole: Sharp directional move
Flag: Parallel channel, opposite direction (slight retracement 38-50%)
Entry: Break of flag boundary in pole direction
Target: Flagpole length projected from breakout
SL: Opposite side of flag
Timeframe: Flag should take 1/3 time of pole

PENNANT:
Same as flag but consolidation is converging triangle
→ Tighter, often faster breakout

ASCENDING TRIANGLE:
Flat top resistance + rising support
Bullish bias (65% break upward)
Target: Height of triangle from breakout

DESCENDING TRIANGLE:
Flat bottom support + falling resistance
Bearish bias (65% break downward)
Target: Height of triangle from breakdown

SYMMETRICAL TRIANGLE:
No directional bias — wait for breakout direction
Often breaks in direction of prior trend
Volume squeeze during formation = explosive breakout likely

RISING WEDGE (in uptrend) = BEARISH reversal signal
FALLING WEDGE (in downtrend) = BULLISH reversal signal

CUP & HANDLE:
Long rounded bottom (cup) + small dip (handle)
Bullish continuation, usually on weekly/monthly
Target: Depth of cup projected from breakout

RECTANGLE/BOX:
Flat top + flat bottom = range/consolidation
Breakout direction = continuation
Target: Height of rectangle
```

---

## 2.4 INDICATORS — DEEP CONFIGURATION

### Moving Averages — Advanced Usage
```
CONFIGURATIONS:
Scalpers:  5, 10, 20 EMA
Day Traders: 20, 50, 100 EMA
Swing Traders: 50, 100, 200 SMA
Position Traders: 100, 200 SMA

ADVANCED TECHNIQUES:
1. MA Angle: Steep angle = strong trend | Flat = weak/no trend
2. Price-to-MA Distance: Price too far = mean reversion likely
   → Use Bollinger Bands to quantify distance
3. MA Cross + ADX Filter:
   → Only trade cross when ADX > 20
   → Avoids whipsaw in ranging markets
4. Multiple MA Alignment:
   → All MAs stacked in order = very strong trend
   → MAs messy/crossing = avoid trending strategies
5. Dynamic S/R:
   → Price touches 50 EMA in uptrend = buy zone
   → Price touches 200 SMA = institutional attention level
```

### RSI — Advanced Techniques
```
STANDARD: >70 overbought, <30 oversold, period 14

ADVANCED:
1. Regular Divergence (Reversal):
   Bullish: Price = Lower Low, RSI = Higher Low → BUY signal
   Bearish: Price = Higher High, RSI = Lower High → SELL signal

2. Hidden Divergence (Continuation):
   Bullish: Price = Higher Low, RSI = Lower Low → BUY (uptrend continuation)
   Bearish: Price = Lower High, RSI = Higher High → SELL (downtrend continuation)

3. RSI Failure Swing (Strong Reversal Signal):
   Bullish: RSI dips below 30, bounces above 30, pulls back (doesn't reach 30 again), then breaks previous RSI high
   Bearish: RSI rises above 70, drops below 70, bounces (doesn't reach 70 again), then breaks previous RSI low

4. RSI Range-Shift:
   Uptrend: RSI tends to range 40–80 (avoid <40 entries in uptrend)
   Downtrend: RSI tends to range 20–60 (avoid >60 entries in downtrend)

5. RSI Period Adjustments:
   Scalping: RSI(9) or RSI(7)
   Day Trading: RSI(14) standard
   Swing Trading: RSI(21)
```

### MACD — Full Depth
```
Components: MACD Line (12 EMA - 26 EMA), Signal Line (9 EMA of MACD), Histogram

SIGNAL HIERARCHY (strongest to weakest):
1. MACD Divergence + Zero Line Cross = STRONGEST
2. MACD Divergence alone
3. Zero Line Cross with momentum
4. Signal Line Cross above/below zero
5. Signal Line Cross near zero = WEAKEST (whipsaw risk)

HISTOGRAM ANALYSIS:
→ Increasing histogram bars = momentum building
→ Decreasing histogram bars = momentum fading (potential reversal)
→ Histogram crosses zero = MACD/Signal crossover

BEST TIMEFRAME: MACD works best on 1H+ timeframes
WEAKNESS: Lagging indicator — use with price action confirmation
```

### Bollinger Bands — Full Playbook
```
Setup: 20 SMA middle, 2 standard deviation upper/lower

SQUEEZE (Low Volatility → Breakout Imminent):
→ Bandwidth: (Upper - Lower) / Middle × 100
→ Bandwidth below 6-month low = extreme squeeze = BIG MOVE COMING
→ Combine with Keltner Channel: BB inside KC = 99% reliable squeeze

BOUNCE STRATEGY:
→ Price touches lower band in uptrend = BUY opportunity
→ Price touches upper band in downtrend = SELL opportunity
→ NOT valid in strong trends (price rides the band)

BREAKOUT STRATEGY:
→ Price closes outside band after squeeze = breakout
→ 2 consecutive closes outside band = strong breakout
→ Target: Opposite band

%B INDICATOR:
→ %B = (Close - Lower Band) / (Upper Band - Lower Band)
→ %B > 1 = price above upper band
→ %B < 0 = price below lower band
→ %B crossing 0.5 = midline cross (trend signal)

WALKING THE BANDS:
→ In strong uptrend: price repeatedly touches/exceeds upper band
→ NOT a sell signal — wait for band walk to end
→ Signal: price starts touching middle band = trend weakening
```

### Ichimoku — Complete System
```
COMPONENTS:
Tenkan-sen (9):    (9-period high + 9-period low) / 2
Kijun-sen (26):    (26-period high + 26-period low) / 2
Senkou Span A:     (Tenkan + Kijun) / 2, plotted 26 periods ahead
Senkou Span B:     (52-period high + 52-period low) / 2, plotted 26 ahead
Chikou Span:       Current close, plotted 26 periods back

CLOUD (KUMO):
→ Span A above Span B = Bullish cloud (green)
→ Span B above Span A = Bearish cloud (red)
→ Thick cloud = strong S/R | Thin cloud = weak S/R
→ Kumo twist ahead = potential trend change in 26 periods

SIGNAL STRENGTH:
Strong BUY: Price above cloud + Tenkan above Kijun + Chikou above price 26 periods ago + Bullish cloud
Weak BUY: 2-3 of above conditions met
NEUTRAL: Price inside cloud
Weak SELL: 2-3 bearish conditions
Strong SELL: All conditions bearish (mirror of strong buy)

TK CROSS:
→ Tenkan crosses above Kijun = bullish (best when above cloud)
→ Tenkan crosses below Kijun = bearish (best when below cloud)

OPTIMAL SETTINGS (crypto/stocks): 20, 60, 120 (adjusts for 24/7 markets)
FOREX: Standard 9, 26, 52 (designed for 5-day trading week)
```

---

## 2.5 FIBONACCI — COMPLETE TOOLKIT

### Retracement Levels
```
Key Levels:
23.6% — Shallow retracement, strong trend
38.2% — First real test, common in strong trends  
50.0% — Psychological halfway, not official Fibonacci
61.8% — The "Golden Ratio" — most powerful level
78.6% — Deep retracement, last chance before new low
88.6% — Gartley/Bat pattern completion zone

USAGE:
→ Draw from swing low to swing high (for uptrend retracement)
→ Wait for price to reach level + confirmation candle
→ Enter with SL below next level
→ Stack Fibonacci with horizontal S/R for confluence

GOLDEN ZONE: 61.8% – 78.6% = Premium entry zone
```

### Fibonacci Extensions (Targets)
```
100% = Equal measured move
127.2% = Common first extension target  
141.4% = Intermediate target
161.8% = Golden extension — most common TP level
200% = Second measured move
261.8% = Very extended moves

USAGE: Draw extension from A→B→C to project D target
```

### Fibonacci Clusters (Power Move)
```
When multiple Fibonacci levels from different swings converge at same price:
→ Fibonacci Cluster = Extremely powerful S/R zone
→ Method: Draw multiple Fibonacci from different swing points
→ Where 3+ levels overlap within 10-20 pips = HIGH PROBABILITY ZONE
```

---

## 2.6 MULTI-TIMEFRAME ANALYSIS (MTF)

### Standard Combinations
| Style | HTF (Trend) | MTF (Setup) | LTF (Entry) |
|---|---|---|---|
| Scalping (1-5M) | 1H | 15M | 5M or 1M |
| Day Trading | 4H | 1H | 15M |
| Swing Trading | Daily | 4H | 1H |
| Position Trading | Weekly | Daily | 4H |

### MTF Decision Tree
```
Step 1: HTF — What is the TREND?
   → Mark major S/R levels
   → Determine overall bias (bullish/bearish/ranging)
   → Note any key price zones

Step 2: MTF — Where is the SETUP?
   → Find pattern formation
   → Identify potential entry zone (OB, FVG, S/R)
   → Assess setup quality

Step 3: LTF — WHEN to ENTER?
   → Wait for trigger candle
   → Precise entry with tight SL
   → Confirm volume/momentum

GOLDEN RULE: Only trade LTF setups that ALIGN with HTF bias
EXCEPTION: Clear HTF reversal signal with multiple confluences
```

---

## 2.7 SUPPORT & RESISTANCE MASTERY

### Identification Hierarchy
```
STRONGEST → WEAKEST:
1. Weekly/Monthly S/R (Institutional levels)
2. Daily S/R (Major swing points)
3. Round numbers (1.2000, 1.3500)
4. Fibonacci levels (especially 61.8%)
5. Previous week high/low
6. 200 SMA (institutional moving average)
7. 4H/1H S/R (Intraday relevance)
8. Dynamic S/R (50 EMA, trend lines)

CONFLUENCE SCORING:
Each factor adds +1 to zone strength
≥3 factors = HIGH CONFLUENCE ZONE (trade with confidence)
1-2 factors = Low confluence (proceed with caution)
```

### Pivot Points (Daily)
```
Standard:
PP = (High + Low + Close) / 3
R1 = 2×PP - Low        S1 = 2×PP - High
R2 = PP + (High-Low)   S2 = PP - (High-Low)
R3 = High + 2(PP-Low)  S3 = Low - 2(High-PP)

Camarilla (Better for intraday):
R4 = Close + (High-Low) × 1.1/2   ← Breakout level
R3 = Close + (High-Low) × 1.1/4   ← Reversal sell zone
S3 = Close - (High-Low) × 1.1/4   ← Reversal buy zone
S4 = Close - (High-Low) × 1.1/2   ← Breakout level

Woodie (Gives more weight to close):
PP = (High + Low + 2×Close) / 4

USAGE:
→ Pre-session: Mark all pivots
→ Trade bounces from R3/S3 (Camarilla) in ranging markets
→ Trade breakouts of R4/S4 in trending markets
→ PP acts as daily magnet/target
```
