# MODULE 07 — TRADING JOURNAL & PERFORMANCE METRICS

## 7.1 COMPLETE TRADE LOG SYSTEM

### Trade Entry Form
```
╔══════════════════════════════════════════════════════╗
║                  TRADE TICKET #[XXX]                 ║
╠══════════════════════════════════════════════════════╣
║ DATE/TIME     : [DD/MM/YYYY HH:MM UTC]               ║
║ PAIR          : [XXX/YYY]                            ║
║ DIRECTION     : BUY / SELL                           ║
║ SESSION       : Tokyo / London / NY / Overlap        ║
╠══════════════════════════════════════════════════════╣
║ ANALYSIS                                             ║
║ HTF Trend     : [Bullish/Bearish/Ranging] [TF]       ║
║ Setup Type    : [see setup codes below]              ║
║ Confluences   : [list 3+ factors]                    ║
║ News Risk     : [None / Low / Medium / High]         ║
╠══════════════════════════════════════════════════════╣
║ LEVELS                                               ║
║ Entry Price   : [X.XXXXX]                           ║
║ Stop Loss     : [X.XXXXX] ([XX] pips)               ║
║ Take Profit 1 : [X.XXXXX] ([XX] pips)               ║
║ Take Profit 2 : [X.XXXXX] ([XX] pips)               ║
║ R:R Ratio     : 1:[X.X]                             ║
╠══════════════════════════════════════════════════════╣
║ POSITION                                             ║
║ Account Bal   : $[XXXXX]                             ║
║ Risk %        : [X]%  = $[XXX]                       ║
║ Lot Size      : [X.XX] lots                          ║
╠══════════════════════════════════════════════════════╣
║ OUTCOME                                              ║
║ Exit Price    : [X.XXXXX]                            ║
║ Exit Reason   : TP1/TP2/SL/Manual/Trail              ║
║ Pips P&L      : +/- [XXX] pips                       ║
║ Dollar P&L    : +/- $[XXX]                           ║
║ R Multiple    : +[X]R / -[X]R                        ║
║ Result        : WIN / LOSS / BREAK-EVEN              ║
╠══════════════════════════════════════════════════════╣
║ REFLECTION                                           ║
║ Followed Plan : YES / NO — [explain if no]           ║
║ Execution     : ★★★★★ (1-5)                         ║
║ Lesson Learned: [one key takeaway]                   ║
╚══════════════════════════════════════════════════════╝

SETUP CODES:
TF = Trend Following | RB = Range Bounce | BO = Breakout
PA = Price Action | ICT = ICT/SMC | WY = Wyckoff
HA = Harmonic | NW = News | CB = Carry Trade
```

---

## 7.2 PERFORMANCE METRICS CALCULATOR

### Core Metrics
```
WIN RATE = (Winners / Total Trades) × 100
→ Alone means nothing without R:R context
→ Win rate context:
   40% WR + 1:2 R:R = profitable ✅
   60% WR + 1:0.5 R:R = losing ❌

PROFIT FACTOR = Gross Profit / Gross Loss
→ Must be > 1.0 to be profitable
→ 1.0-1.5: Marginal | 1.5-2.0: Good | >2.0: Excellent
→ Sustainable trading systems: PF 1.3-2.5

EXPECTANCY (per trade):
= (Win Rate × Avg Win) - (Loss Rate × Avg Loss)
→ Positive = system has edge
→ Example: 45% WR, avg win $200, avg loss $100
→ E = (0.45 × 200) - (0.55 × 100) = 90 - 55 = $35/trade

AVERAGE R MULTIPLE:
= Sum of all R multiples / Total trades
→ R multiple = actual P&L in $ / initial risk in $
→ Win of $300 with $100 risk = +3R
→ Average R > 0 = profitable system
```

### Advanced Metrics
```
SHARPE RATIO:
= (Average Return - Risk-Free Rate) / Standard Deviation of Returns
→ >1.0: Acceptable | >2.0: Good | >3.0: Excellent
→ For monthly data: use monthly returns
→ Measures return per unit of volatility

SORTINO RATIO:
Similar to Sharpe but only penalizes DOWNSIDE volatility
= (Average Return - Risk-Free Rate) / Downside Deviation
→ Better metric than Sharpe for trading
→ >2.0 = good

MAX DRAWDOWN (MDD):
= (Peak Value - Trough Value) / Peak Value × 100%
→ Should stay below 20% for retail | 10% for prop firms

MAX CONSECUTIVE LOSSES:
→ Track this carefully — affects psychology
→ If you know max is 5, 4 losses in a row is normal, not a failure

RECOVERY FACTOR:
= Net Profit / Maximum Drawdown
→ >2.0 = decent | >3.0 = good | >5.0 = excellent

CALMAR RATIO:
= Annualized Return / Maximum Drawdown
→ >1.0: Acceptable | >2.0: Good

AVERAGE TRADE DURATION:
→ Helps understand if you're cutting winners too short
→ Compare: avg winning trade duration vs avg losing trade duration
→ Winning trades should last LONGER than losing trades ideally
```

---

## 7.3 PERFORMANCE REVIEW FRAMEWORK

### Weekly Review Process
```
EVERY FRIDAY/WEEKEND:
1. Calculate week's P&L and R multiples
2. Review each trade against plan
3. Grade execution (not just outcome)
4. Identify patterns in losses

QUESTIONS TO ASK:
□ Did I follow my trading plan on every trade?
□ Were my SL placements logical or emotional?
□ Did I skip good setups? Why?
□ Did I take low-quality setups? Why?
□ What was my win rate this week vs expectation?
□ Did any emotional biases affect my decisions?
□ What's my profit factor for the week?
```

### Monthly Deep Review
```
MONTHLY ANALYTICS:
□ Calculate all core metrics (WR, PF, Expectancy, MDD)
□ P&L by pair — which pairs are you most profitable in?
□ P&L by session — best time to trade
□ P&L by setup type — which setups work for you?
□ P&L by day of week — any patterns?
□ P&L by month/hour of day

EQUITY CURVE ANALYSIS:
→ Plot cumulative P&L (R multiples) over time
→ Smooth rising curve = consistent system
→ Volatile/jagged = inconsistent sizing or discipline issues
→ Long flat periods = strategy needs review
→ Drawdown periods: identify what changed
```

---

## 7.4 BACKTESTING FRAMEWORK

### Manual Backtesting Protocol
```
SETUP:
→ Use TradingView, MT4/MT5 historical data
→ Scroll back 12+ months of data
→ Test on 200+ trades minimum for statistical significance
→ Do NOT cherry-pick — test ALL qualifying setups

PROCESS:
1. Define rules BEFORE starting (no changing mid-test)
2. For each bar: ask "Does this meet entry criteria?"
3. If yes: record hypothetical entry, SL, TP
4. Let trade play out, record result
5. Track in spreadsheet: date, pair, direction, entry, SL, TP, result, R

WHAT TO MEASURE:
- Win rate
- Profit factor
- Average R multiple
- Max consecutive losses
- Max drawdown in R
- Setup frequency (trades per month)

SAMPLE SIZE REQUIREMENTS:
- 100 trades: Rough estimate only
- 200 trades: Statistical significance begins
- 500+ trades: High confidence in metrics

CAUTION: Past performance does not guarantee future results
Market regimes change — retest every 6 months
```

### Forward Testing (Paper Trading)
```
BEFORE GOING LIVE:
1. Paper trade for minimum 1-2 months
2. Trade as if real money (same position sizes, same emotions attempted)
3. Compare forward test metrics to backtest
4. If significant difference → review rules

GRADUATION CRITERIA (Real Money):
□ 50+ paper trades completed
□ Positive expectancy confirmed
□ Profit factor > 1.3
□ Max 3 consecutive losses handled well emotionally
□ Strategy rules written and memorized
□ Risk management rules non-negotiable
```

---

## 7.5 PROP FIRM CHALLENGE TRACKER

### Common Prop Firm Rules
```
TYPICAL CHALLENGE PARAMETERS:
Daily Loss Limit: 4-5% of account
Total Loss Limit: 8-10% of account
Profit Target: 8-10% (phase 1), 5% (phase 2)
Minimum Trading Days: 5-10 days
Maximum Position Size: 5% per trade risk

PROP FIRM SPECIFIC RULES:
→ News trading: Some firms ban trading 2 min before/after news
→ Weekend holds: Some firms ban holding over weekend
→ Lot size consistency: Some require consistent sizing
→ Drawdown calculation: EOD vs real-time (critical difference!)
  → EOD: Drawdown measured on close, intraday doesn't count
  → Real-time: Any intraday dip counts = stricter

OPTIMAL CHALLENGE STRATEGY:
→ Risk 0.5-1% per trade (half of normal)
→ 5+ trades per week to meet minimum days
→ Stop trading when daily loss reaches 3% (buffer before 4-5% limit)
→ Take profits consistently, don't chase 10% in first week
→ Treat it like a marathon, not a sprint
```
