# MODULE 06 — CLASSIC TRADING STRATEGIES

## 6.1 TREND FOLLOWING SYSTEM

### Trend Identification Checklist
```
CONFIRM TREND BEFORE ENTRY:
□ Price above/below 200 SMA (major bias)
□ Price above/below 50 SMA (medium bias)
□ ADX(14) > 25 (trend has strength)
□ MACD histogram in correct direction
□ Higher TF confirms same direction
□ Market structure: HH+HL (bull) or LH+LL (bear)

WEAK TREND FILTERS (avoid if present):
✗ ADX < 20
✗ Price whipsawing around 50 SMA
✗ MACD histogram shrinking
✗ Recent CHoCH on HTF
```

### Entry Methods for Trend Trading
```
METHOD 1: Pullback to EMA
→ In uptrend, wait for pullback to 20 or 50 EMA
→ Entry: Bullish candle bouncing off EMA
→ SL: Below EMA + ATR buffer (1.5x ATR)
→ TP: Previous high or 1.5x-2x SL distance

METHOD 2: S/R Retest
→ Previous resistance breaks → becomes support
→ Wait for price to retest broken level
→ Entry: Rejection candle at new support
→ SL: Below the structure
→ TP: Next resistance level

METHOD 3: MA Crossover (confirmed)
→ 20 EMA crosses 50 EMA + ADX > 25
→ Don't enter on cross itself — wait for retest
→ Entry: Price pulls back to 20 or 50 EMA after cross
→ SL: Below 50 EMA
→ TP: 2x SL distance or next major S/R

METHOD 4: Flag/Channel Breakout
→ In trend, price forms consolidation (flag)
→ Entry: Break of flag boundary in trend direction
→ SL: Opposite side of flag
→ TP: Flagpole length projected
```

---

## 6.2 RANGE TRADING SYSTEM

### Identifying a Valid Range
```
CRITERIA:
□ ADX < 25 (preferably < 20)
□ Two or more clear touches of top boundary
□ Two or more clear touches of bottom boundary
□ Boundaries are within 100-200 pip range (forex standard)
□ No imminent high-impact news

RANGE QUALITY SCORE:
+1: ADX < 20
+1: 3+ touches on each boundary
+1: Range width 80-200 pips
+1: Range has lasted 2+ days
+1: Aligned with HTF S/R
Score ≥ 3 = High quality range, trade it
Score < 3 = Skip or trade with reduced size
```

### Range Entry Protocol
```
BUY AT SUPPORT:
1. Price reaches range bottom
2. RSI < 35 (oversold within range)
3. Stochastic < 20 and starting to cross up
4. Bullish reversal candle appears (hammer, engulfing, doji)
5. ENTRY: Open of next candle after signal
6. SL: 5-10 pips below range bottom
7. TP1: 50% of range (midpoint)
8. TP2: 80% of range (near top, not AT top)

SELL AT RESISTANCE:
Mirror of above
→ RSI > 65 | Stochastic > 80 | Bearish candle
→ TP targets: 50% midpoint then 80% toward bottom

MIDLINE FILTER:
→ Only buy at bottom if price is BELOW midline
→ Only sell at top if price is ABOVE midline
→ Avoids entering in the "dead zone" of the range
```

### Range Breakout Trading
```
SETUP AFTER RANGE:
→ Breakout candle closes outside range boundary
→ Volume spike on breakout (if available)
→ Second candle in breakout direction = confirmation
→ Entry: Retest of broken level (safer) or immediate breakout candle close

FALSE BREAKOUT FILTER:
→ Wait for candle CLOSE outside range (not just wick)
→ "Three drives" failure: 3rd push often fails → wait
→ If breakout < 20 pips beyond boundary = likely false
→ News-driven breakouts less reliable (often reverses)
```

---

## 6.3 BREAKOUT TRADING SYSTEM

### High-Probability Breakout Setup
```
CRITERIA:
□ Clear consolidation pattern (triangle, rectangle, wedge, flag)
□ ATR contracting (volatility squeeze)
□ Volume decreasing during consolidation (spring loading)
□ HTF trend aligns with breakout direction
□ No major resistance within 50 pips of entry

TIMING:
→ Session breakouts: Most reliable at London open, NY open
→ Asia range breakout at London open = high probability setup
→ Pre-announcement consolidation: Avoid (news-dependent)
```

### Breakout Entry Types
```
AGGRESSIVE ENTRY (higher risk, better R:R):
→ Enter on breakout candle close
→ SL: Back inside consolidation
→ Risk: Higher false breakout rate

CONSERVATIVE ENTRY (lower risk, lower R:R):
→ Wait for retest of broken level
→ Enter on confirmation candle at retest
→ May miss trade if no retest occurs
→ Better win rate, more patient required

ORB (Opening Range Breakout):
→ Mark first 15-30 min range of NY/London open
→ Trade break of that range in trending session
→ Very mechanical, good for rule-based traders
```

---

## 6.4 NEWS TRADING STRATEGIES

### Straddle Strategy (Pre-News)
```
WARNING: High risk, only for experienced traders

SETUP:
1. Identify high-impact news (NFP, CPI, FOMC)
2. 2-5 min before release: Place both BUY STOP and SELL STOP
3. Levels: 15-20 pips above/below current price
4. SL: 15-20 pips (tight), TP: 50-100 pips

RISKS:
→ Spread widens dramatically at news = fills at terrible price
→ Spike and reverse = both orders hit = double loss
→ Slippage with market makers

BETTER APPROACH (Post-News):
→ Wait for initial spike + stabilization (2-5 min)
→ Identify direction of true move
→ Enter on first pullback after spike
→ SL: Below/above the spike extreme
→ TP: 2x the initial spike size
```

### Fundamental + Technical Confluence Trade
```
FRAMEWORK:
1. Identify fundamental catalyst (economic data surprise)
2. Confirm with technical setup (trend + level)
3. Enter in direction of BOTH fundamentals and technicals

Example:
→ NFP beats massively (USD fundamental bullish)
→ USD/JPY breaks above key resistance with volume (technical)
→ CONFLUENCE TRADE: Buy USD/JPY retest of broken resistance
→ This is the most powerful type of trade
```

---

## 6.5 TRADE MANAGEMENT SYSTEM

### Stop Loss Management
```
INITIAL SL PLACEMENT:
1. Structure-Based: Below swing low/high (most logical)
2. ATR-Based: Entry ± (1.5 × ATR14) (volatility-adjusted)
3. Support/Resistance: Below nearest key level
4. Candle-Based: Below signal candle low + 5 pip buffer

TRAILING SL METHODS:
1. Manual Trailing: Move SL to below each new HL
2. ATR Trail: SL = Current price - 2×ATR (auto-adjusts)
3. MA Trail: SL at 20 EMA (for strong trends)
4. Parabolic SAR: Auto-trailing indicator
5. Structure Trail: Move SL after each BOS

BREAK-EVEN RULE:
→ Move SL to entry when trade reaches 1:1 R:R
→ Conditions: Only move if price has broken structure in favor
→ Never move SL further INTO loss (biggest mistake)
```

### Scaling In & Out
```
SCALING IN (Add to winning position):
→ Only add when trade is already profitable (>20 pips in profit)
→ Add maximum 50% of original size
→ Move SL of original position to breakeven first
→ New position gets its own SL at new structure point
→ Average entry price rises — manage carefully

SCALING OUT (Take partial profits):
→ TP1 (50% position): First target (1:1 R:R or first S/R)
→ TP2 (25% position): Second target (1:2 R:R)
→ TP3 (25% position): Run with trail SL
→ Benefits: Locks in profit, reduces psychological pressure
→ Trade-off: Reduces maximum profit if trade runs far
```

### The 3 Trade Management Styles
```
STYLE 1 — SET AND FORGET (Recommended for beginners):
→ Set SL and TP before entry, do not touch
→ Pros: No emotional interference, respects original analysis
→ Cons: Misses extended moves, full loss if trade fails

STYLE 2 — ACTIVE MANAGEMENT:
→ Move to BE at 1:1, trail SL manually
→ Pros: Protects profits, can ride trends
→ Cons: Can be stopped out of valid trades by noise

STYLE 3 — SCALING (Advanced):
→ Enter in 2-3 tranches, scale out at targets
→ Pros: Maximum flexibility, good for uncertain entries
→ Cons: Complex, higher cognitive load
```
