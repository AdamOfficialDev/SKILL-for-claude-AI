# MODULE 05 — ADVANCED STRATEGIES (SMC · ICT · WYCKOFF · HARMONIC)

## 5.1 SMART MONEY CONCEPTS (SMC)

### Core Philosophy
```
Smart Money = Banks, Hedge Funds, Institutional Traders
Retail Money = Retail traders (us)

Smart money NEEDS:
→ LIQUIDITY to fill huge orders (stop losses = liquidity pools)
→ They hunt retail stop losses BEFORE moving in their direction
→ They leave footprints: Order Blocks, FVGs, liquidity sweeps

Our edge: READ the footprints, trade WITH them
```

### Liquidity Pools
```
WHERE LIQUIDITY LIVES:
1. Above swing highs (buy stops of shorts, SL of longs)
2. Below swing lows (sell stops of longs, SL of shorts)
3. Above/below equal highs/lows (double tops/bottoms)
4. At psychological round numbers
5. At trendlines (everyone's SL is just beyond)

LIQUIDITY SWEEP (Stop Hunt):
→ Price spikes past key high/low, immediately reverses
→ This is institutions harvesting retail stop losses
→ TRADE SIGNAL: Sweep + reversal candle = strong entry

Equal Highs (EQH) / Equal Lows (EQL):
→ Multiple touches at same price = RESTING LIQUIDITY
→ High probability that price will "grab" that liquidity
→ After grab → strong reversal expected
```

### Order Blocks (OB)
```
DEFINITION:
Last bearish candle BEFORE strong bullish impulse = Bullish OB
Last bullish candle BEFORE strong bearish impulse = Bearish OB

WHY THEY WORK:
→ Institutions placed large orders at these levels
→ When price returns, they add more (defend their position)
→ Acts as high-probability S/R

IDENTIFYING QUALITY OBs:
✅ Preceded by a Break of Structure or CHoCH
✅ Clear impulsive move away (3+ candles)
✅ Leaves Fair Value Gap (see below)
✅ On Higher Timeframe (D/4H more powerful than 15M)

ENTRY AT OB:
→ Price returns to OB zone
→ Look for reaction (rejection candle, engulfing)
→ Enter at 50% of OB candle body
→ SL: Below/above full OB candle + buffer
→ TP: Next liquidity pool or opposing OB

OB INVALIDATION:
→ Price closes THROUGH the OB (50%+ candle close beyond)
→ OB should hold, a breach = invalid = skip trade
```

### Fair Value Gaps (FVG) / Imbalance
```
DEFINITION:
3-candle sequence where candle 1 high and candle 3 low DON'T overlap
= Gap in price where no trading occurred = IMBALANCE

Bullish FVG: Candle 1 high < Candle 3 low (gap above)
Bearish FVG: Candle 1 low > Candle 3 high (gap below)

WHY THEY FILL:
→ Markets are efficient — gaps tend to be filled
→ Institutions use FVG as reference for re-entries
→ After filling, strong continuation expected

FVG ENTRY METHOD:
→ Mark FVG zone (between candle 1 extreme and candle 3 extreme)
→ Wait for price to enter the FVG
→ Entry at 50% of FVG (the "equilibrium" within the gap)
→ SL beyond the FVG + 5-10 pip buffer

PREMIUM FVG = Gap on HTF (Daily/4H) > More powerful
DISCOUNT FVG = Gap on LTF (15M/5M) > Less powerful, use for precision entry
```

### Inducement (IDM)
```
Inducement = False signal designed to trap retail traders

HOW TO SPOT:
→ Small swing point before main structure (e.g., minor HL in downtrend)
→ Price runs above that minor HL (induces longs)
→ Then continues DOWN (retail longs trapped)

SEQUENCE:
IDM sweep → BOS → entry in direction of BOS
→ The IDM IS the liquidity grab before the real move
```

---

## 5.2 ICT (INNER CIRCLE TRADER) CONCEPTS

### Kill Zones (Optimal Entry Times)
```
LONDON KILL ZONE: 02:00 – 05:00 New York Time (07:00-10:00 UTC)
→ Best for: EUR/USD, GBP/USD, EUR/GBP
→ Often sets daily bias

NEW YORK KILL ZONE: 07:00 – 10:00 New York Time (12:00-15:00 UTC)
→ Best for: All USD pairs
→ Highest volume, most manipulation

LONDON CLOSE: 10:00 – 12:00 NY Time (15:00-17:00 UTC)
→ Reversal opportunities as London closes positions

ASIAN KILL ZONE: 20:00 – 23:00 NY Time (01:00-04:00 UTC)
→ Best for: JPY pairs, AUD, NZD
→ Slower, range-bound
```

### Optimal Trade Entry (OTE)
```
OTE = 61.8% – 79% retracement zone of a swing move

METHOD:
1. Identify swing high and swing low
2. Draw Fibonacci from swing low to swing high
3. OTE Zone = 61.8% to 79% retracement
4. Wait for price to enter OTE + reaction confirmation
5. Target: Previous high/low (100%) or extension levels

CONFLUENCE: OTE + Order Block + FVG = HIGHEST PROBABILITY ENTRY
```

### Power of Three (AMD Concept)
```
ACCUMULATION: Smart money accumulates positions (narrow range, often during Asia)
MANIPULATION: False move to trap retail (London kill zone often)
DISTRIBUTION: True move in intended direction (New York session often)

DAILY APPLICATION:
→ Asia session creates range (accumulation)
→ London session fakes in one direction (manipulation — take out stops)
→ NY session moves in TRUE direction (distribution)

TRADE THE DISTRIBUTION PHASE:
→ Watch Asia range
→ Note which direction London breaks (manipulation side)
→ When London reverses after spike = enter for NY distribution
```

### ICT Market Maker Model
```
BULLISH MARKET MAKER MODEL:
1. Old Low created (sell side liquidity resting below)
2. Price draws DOWN to sweep that liquidity
3. Reversal confirmation (displacement candle)
4. Price rallies to old high (buy side liquidity target)

BEARISH MARKET MAKER MODEL:
1. Old High created (buy side liquidity resting above)
2. Price draws UP to sweep that liquidity  
3. Reversal confirmation (displacement candle)
4. Price drops to old low (sell side liquidity target)

SEQUENCE: Consolidation → Sweep → Reversal → Leg to liquidity target
```

---

## 5.3 WYCKOFF METHOD

### Accumulation Schematic
```
PHASE A: Stopping the downtrend
→ Preliminary Support (PS): First buying attempts
→ Selling Climax (SC): Panic selling, heavy volume, candle reversal
→ Automatic Rally (AR): Sharp bounce from SC
→ Secondary Test (ST): Retest of SC area, less volume

PHASE B: Building the cause
→ Multiple tests of the trading range
→ Springs (false breakdowns) to shakeout weak hands
→ Volume analysis key: high vol at lows = accumulation

PHASE C: Testing (Spring)
→ Spring: Final bear trap — breaks below range low, quickly recovers
→ "Shakeout": More aggressive spring
→ Spring + no follow-through selling = strong bullish signal

PHASE D: Mark-up begins
→ Sign of Strength (SOS): Strong rally through range on high volume
→ Last Point of Support (LPS): Retest of former resistance as support
→ Enter on LPS retest

PHASE E: Uptrend
→ Price leaves the range
→ Add on pullbacks (LPS levels)
```

### Distribution Schematic
```
Mirror image of accumulation:
Phase A: Stop of uptrend (PSY, BC, AR, ST)
Phase B: Building the cause for decline (SOW signals)
Phase C: UTAD (Upthrust After Distribution) = Bear trap for longs
Phase D: Mark-down begins (LPSY = Last Point of Supply)
Phase E: Downtrend in force
```

### Wyckoff Laws
```
LAW 1 — SUPPLY & DEMAND:
When demand > supply → price rises
When supply > demand → price falls
Volume analysis confirms which is dominant

LAW 2 — CAUSE & EFFECT:
Cause (accumulation period) → Effect (uptrend magnitude)
Longer the range = bigger the potential move
Point & Figure charts used to measure the "cause"

LAW 3 — EFFORT vs RESULT:
High volume + small price move = hidden opposition (effort ≠ result)
Low volume + large price move = easy movement, no opposition
Volume divergence = warning sign
```

---

## 5.4 HARMONIC PATTERNS

### Pattern Rules — Fibonacci Ratios
```
GARTLEY:
XA: Initial move
AB: 61.8% retracement of XA
BC: 38.2%–88.6% retracement of AB
CD: 127.2%–161.8% extension of BC
D: 78.6% retracement of XA ← ENTRY ZONE (PRZ)

BAT:
AB: 38.2%–50% of XA
BC: 38.2%–88.6% of AB
CD: 161.8%–261.8% of BC
D: 88.6% of XA ← ENTRY (deepest pullback)

BUTTERFLY:
AB: 78.6% of XA
BC: 38.2%–88.6% of AB
CD: 161.8%–261.8% of BC
D: 127.2%–161.8% of XA ← ENTRY (beyond X point)

CRAB:
AB: 38.2%–61.8% of XA
BC: 38.2%–88.6% of AB
CD: 224%–361.8% of BC
D: 161.8% of XA ← Deepest harmonic pattern

SHARK:
0B: Any impulse
BC: 113%–161.8% of 0B
CD: 88.6%–113% of XA (or 50% of BC)
Entry at C completion
```

### PRZ (Potential Reversal Zone) Trading
```
PRZ = Confluence of multiple Fibonacci ratios at "D" point

ENTRY PROTOCOL:
1. Identify complete pattern (all ratios must validate)
2. Wait for price to enter PRZ zone
3. Look for confirmation: reversal candle, RSI divergence
4. Enter at 50% of the confirmation candle
5. SL: Beyond PRZ boundary + 5-10 pip buffer
6. TP1: 38.2% retracement of CD leg
7. TP2: 61.8% retracement of CD leg
8. TP3: A point (full pattern reversal)

VALIDITY CHECK:
→ All legs must respect their Fibonacci ratios (within 5% tolerance)
→ If ANY ratio is off by >5% = pattern invalid = skip
```

---

## 5.5 DIVERGENCE MASTERY

### Regular Divergence (Counter-trend / Reversal)
```
BULLISH REGULAR:
Price: Lower Low (LL)
Indicator: Higher Low (HL)
→ Bearish momentum weakening
→ SELL-off is losing steam
→ Signal: BUY reversal

BEARISH REGULAR:
Price: Higher High (HH)
Indicator: Lower High (LH)
→ Bullish momentum weakening
→ Rally is losing steam
→ Signal: SELL reversal

Best Indicators for Divergence: RSI, MACD, Stochastic, CCI
```

### Hidden Divergence (Trend Continuation)
```
BULLISH HIDDEN:
Price: Higher Low (HL) — in uptrend pullback
Indicator: Lower Low (LL)
→ Pullback is weak, trend will continue UP
→ Signal: BUY continuation

BEARISH HIDDEN:
Price: Lower High (LH) — in downtrend bounce
Indicator: Higher High (HH)
→ Bounce is weak, trend will continue DOWN
→ Signal: SELL continuation

★ Hidden divergence is VERY powerful in strong trending markets
★ Regular divergence is more powerful at key S/R levels
```

### Exaggerated Divergence
```
Price: Equal High or Double Top
Indicator: Lower High
→ Same as regular bearish but more subtle
→ Often precedes sharp reversals

Price: Equal Low or Double Bottom
Indicator: Higher Low
→ Same as regular bullish but subtle
```
